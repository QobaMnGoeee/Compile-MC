# BBS Shell

Android терминал қолданбасы. Termux негізінде жасалған форк: жаңа атау, жаңа пакет атауы (`kz.bbsshell.app`), жаңа дизайн және 12 тақырып.

## Не өзгерді

- **Атауы мен пакеті:** `com.termux` → `kz.bbsshell.app`. Барлық Java пакеттері `kz.bbsshell.*` болды. Класс, ресурс, константа атаулары `BbsShell*`, `BBSSHELL_*`, `bbsshell_*` болып өзгертілді.
- **Termux плагиндері алынып тасталды:** Termux:API, Tasker, Float, Widget, Boot, Styling. Олардың баптаулар экрандары мен кодтары жойылды. RUN_COMMAND интерфейсі сақталды (`kz.bbsshell.app.permission.RUN_COMMAND`).
- **Дизайн:** Қараңғы glassmorphism интерфейс. Негізгі акцент түсі — cyan `#22D3EE`. Неон эффектісі жоқ.
- **Тақырыптар:** Сол жаққа сырғытқанда (drawer) тақырыптар жолағы шығады. 12 тақырып бар: Cyan Glass, Midnight, Graphite, Nord, Forest, Teal Lagoon, Violet Haze, Rose Dusk, Amber Night, Solarized, Slate, Mocha. Таңдау сақталады және терминал палитрасына да қолданылады.
- **Пернетақта жолағы (HotKeys):** Тек `CTRL`, `←`, `→`, `↑`, `↓` және `Paste` батырмалары қалды.
- **Кіру кезіндегі хабарлама:** Bootstrap-тағы `motd` файлдары бос жазылады, сондықтан welcome мәтіні көрінбейді.
- **Логотип:** Жаңа glass-стиль белгі (`app/src/main/res/mipmap-*`, adaptive icon және monochrome notification icon). Мастер файл: `scratchpad/work/logo/bbsshell-logo.svg`.
- **Жойылды:** `fastlane/`, `art/`, `jitpack.yml`, TV banner, release keystore (`dev_keystore.jks` сілтемесі).

## Құрастыру алдында міндетті қадам: bootstrap

Терминалдың Linux ортасы (bash, apt, coreutils, т.б.) bootstrap архивінде жатыр. Бұл архивтердегі бинарлар мен скрипттер `/data/data/com.termux/files/usr` жолын қатаң кодтайды. Сондықтан бұл жобаға Termux-тың дайын bootstrap-ын қолдану мүмкін емес: терминал іске қосылмайды.

Өз bootstrap-ыңызды termux-packages инструментімен `kz.bbsshell.app` префиксімен жинаңыз:

- Префикс: `/data/data/kz.bbsshell.app/files/usr`
- Файлдар: `app/src/main/cpp/bootstrap-aarch64.zip`, `bootstrap-arm.zip`, `bootstrap-i686.zip`, `bootstrap-x86_64.zip`

Файлдар жоқ болса, Gradle құрастыруды түсінікті қате хабарламасымен тоқтатады.

## Белгілі шектеулер

- Бұл сессияда Android SDK және Gradle құрастыру мүмкін болмады. Тек Java синтаксисі (плагин кодтары алынғаннан кейінгі 140 файл) және барлық XML файлдары тексерілді. Құрастыру мен іске қосуды өз компьютеріңізде тексеріңіз.
- Сілтемелер `bbsshell.example` және `github.com/bbsshell` — орын толтырғыштар. Өз доменіңіз бен репозиторийіңізбен ауыстырыңыз (`BbsShellConstants.java`).
- Bootstrap ішіндегі `termux-*` командалары (мысалы `termux-open`) пакеттер жинағынан келеді. Оларды өз bootstrap-ыңызда да атаңыз.

## Лицензия

Бұл жоба Termux кодына негізделген және GPLv3 лицензиясымен таратылады. Бастапқы авторлық құқық туралы ескертулер `LICENSE.md` файлында сақталған. Лицензия талабы бойынша оны өзгертуге болмайды.
