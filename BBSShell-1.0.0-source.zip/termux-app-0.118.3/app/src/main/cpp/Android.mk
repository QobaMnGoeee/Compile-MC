LOCAL_PATH:= $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := libbbsshell-bootstrap
LOCAL_SRC_FILES := bbsshell-bootstrap-zip.S bbsshell-bootstrap.c
include $(BUILD_SHARED_LIBRARY)
