package kz.bbsshell.app.settings.properties;

import android.content.Context;

import androidx.annotation.NonNull;

import kz.bbsshell.app.terminal.io.KeyboardShortcut;
import kz.bbsshell.shared.terminal.io.extrakeys.ExtraKeysConstants;
import kz.bbsshell.shared.terminal.io.extrakeys.ExtraKeysConstants.EXTRA_KEY_DISPLAY_MAPS;
import kz.bbsshell.shared.terminal.io.extrakeys.ExtraKeysInfo;
import kz.bbsshell.shared.logger.Logger;
import kz.bbsshell.shared.settings.properties.BbsShellPropertyConstants;
import kz.bbsshell.shared.settings.properties.BbsShellSharedProperties;
import kz.bbsshell.shared.core.BbsShellConstants;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BbsShellAppSharedProperties extends BbsShellSharedProperties {

    private ExtraKeysInfo mExtraKeysInfo;
    private List<KeyboardShortcut> mSessionShortcuts = new ArrayList<>();

    private static final String LOG_TAG = "BbsShellAppSharedProperties";

    public BbsShellAppSharedProperties(@NonNull Context context) {
        super(context, BbsShellConstants.BBSSHELL_APP_NAME, BbsShellPropertyConstants.getBbsShellPropertiesFile(),
            BbsShellPropertyConstants.BBSSHELL_PROPERTIES_LIST, new SharedPropertiesParserClient());
    }

    /**
     * Reload the bbsshell properties from disk into an in-memory cache.
     */
    @Override
    public void loadBbsShellPropertiesFromDisk() {
        super.loadBbsShellPropertiesFromDisk();

        setExtraKeys();
        setSessionShortcuts();
    }

    /**
     * Set the terminal extra keys and style.
     */
    private void setExtraKeys() {
        mExtraKeysInfo = null;

        try {
            // The mMap stores the extra key and style string values while loading properties
            // Check {@link #getExtraKeysInternalPropertyValueFromValue(String)} and
            // {@link #getExtraKeysStyleInternalPropertyValueFromValue(String)}
            String extrakeys = (String) getInternalPropertyValue(BbsShellPropertyConstants.KEY_EXTRA_KEYS, true);
            String extraKeysStyle = (String) getInternalPropertyValue(BbsShellPropertyConstants.KEY_EXTRA_KEYS_STYLE, true);

            ExtraKeysConstants.ExtraKeyDisplayMap extraKeyDisplayMap = ExtraKeysInfo.getCharDisplayMapForStyle(extraKeysStyle);
            if (EXTRA_KEY_DISPLAY_MAPS.DEFAULT_CHAR_DISPLAY.equals(extraKeyDisplayMap) && !BbsShellPropertyConstants.DEFAULT_IVALUE_EXTRA_KEYS_STYLE.equals(extraKeysStyle)) {
                Logger.logError(BbsShellSharedProperties.LOG_TAG, "The style \"" + extraKeysStyle + "\" for the key \"" + BbsShellPropertyConstants.KEY_EXTRA_KEYS_STYLE + "\" is invalid. Using default style instead.");
                extraKeysStyle = BbsShellPropertyConstants.DEFAULT_IVALUE_EXTRA_KEYS_STYLE;
            }

            mExtraKeysInfo = new ExtraKeysInfo(extrakeys, extraKeysStyle, ExtraKeysConstants.CONTROL_CHARS_ALIASES);
        } catch (JSONException e) {
            Logger.showToast(mContext, "Could not load and set the \"" + BbsShellPropertyConstants.KEY_EXTRA_KEYS + "\" property from the properties file: " + e.toString(), true);
            Logger.logStackTraceWithMessage(LOG_TAG, "Could not load and set the \"" + BbsShellPropertyConstants.KEY_EXTRA_KEYS + "\" property from the properties file: ", e);

            try {
                mExtraKeysInfo = new ExtraKeysInfo(BbsShellPropertyConstants.DEFAULT_IVALUE_EXTRA_KEYS, BbsShellPropertyConstants.DEFAULT_IVALUE_EXTRA_KEYS_STYLE, ExtraKeysConstants.CONTROL_CHARS_ALIASES);
            } catch (JSONException e2) {
                Logger.showToast(mContext, "Can't create default extra keys",true);
                Logger.logStackTraceWithMessage(LOG_TAG, "Could create default extra keys: ", e);
                mExtraKeysInfo = null;
            }
        }
    }

    /**
     * Set the terminal sessions shortcuts.
     */
    private void setSessionShortcuts() {
        if (mSessionShortcuts == null)
            mSessionShortcuts = new ArrayList<>();
        else
            mSessionShortcuts.clear();

        // The {@link BbsShellPropertyConstants#MAP_SESSION_SHORTCUTS} stores the session shortcut key and action pair
        for (Map.Entry<String, Integer> entry : BbsShellPropertyConstants.MAP_SESSION_SHORTCUTS.entrySet()) {
            // The mMap stores the code points for the session shortcuts while loading properties
            Integer codePoint = (Integer) getInternalPropertyValue(entry.getKey(), true);
            // If codePoint is null, then session shortcut did not exist in properties or was invalid
            // as parsed by {@link #getCodePointForSessionShortcuts(String,String)}
            // If codePoint is not null, then get the action for the MAP_SESSION_SHORTCUTS key and
            // add the code point to sessionShortcuts
            if (codePoint != null)
                mSessionShortcuts.add(new KeyboardShortcut(codePoint, entry.getValue()));
        }
    }

    public List<KeyboardShortcut> getSessionShortcuts() {
        return mSessionShortcuts;
    }

    public ExtraKeysInfo getExtraKeysInfo() {
        return mExtraKeysInfo;
    }



    /**
     * Load the {@link BbsShellPropertyConstants#KEY_TERMINAL_TRANSCRIPT_ROWS} value from bbsshell properties file on disk.
     */
    public static int getTerminalTranscriptRows(Context context) {
        return  (int) BbsShellSharedProperties.getInternalPropertyValue(context, BbsShellPropertyConstants.getBbsShellPropertiesFile(),
            BbsShellPropertyConstants.KEY_TERMINAL_TRANSCRIPT_ROWS, new SharedPropertiesParserClient());
    }

}
