package kz.bbsshell.app.terminal.io;

import android.annotation.SuppressLint;
import android.view.Gravity;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.drawerlayout.widget.DrawerLayout;

import kz.bbsshell.app.terminal.BbsShellTerminalSessionClient;
import kz.bbsshell.app.terminal.BbsShellTerminalViewClient;
import kz.bbsshell.shared.terminal.io.TerminalExtraKeys;
import kz.bbsshell.view.TerminalView;

public class BbsShellTerminalExtraKeys extends TerminalExtraKeys {


    BbsShellTerminalViewClient mBbsShellTerminalViewClient;
    BbsShellTerminalSessionClient mBbsShellTerminalSessionClient;

    public BbsShellTerminalExtraKeys(@NonNull TerminalView terminalView,
                                   BbsShellTerminalViewClient bbsshellTerminalViewClient,
                                   BbsShellTerminalSessionClient bbsshellTerminalSessionClient) {
        super(terminalView);
        mBbsShellTerminalViewClient = bbsshellTerminalViewClient;
        mBbsShellTerminalSessionClient = bbsshellTerminalSessionClient;
    }

    @SuppressLint("RtlHardcoded")
    @Override
    public void onTerminalExtraKeyButtonClick(View view, String key, boolean ctrlDown, boolean altDown, boolean shiftDown, boolean fnDown) {
        if ("KEYBOARD".equals(key)) {
            if(mBbsShellTerminalViewClient != null)
                mBbsShellTerminalViewClient.onToggleSoftKeyboardRequest();
        } else if ("DRAWER".equals(key)) {
            DrawerLayout drawerLayout = mBbsShellTerminalViewClient.getActivity().getDrawer();
            if (drawerLayout.isDrawerOpen(Gravity.LEFT))
                drawerLayout.closeDrawer(Gravity.LEFT);
            else
                drawerLayout.openDrawer(Gravity.LEFT);
        } else if ("PASTE".equals(key)) {
            if(mBbsShellTerminalSessionClient != null)
                mBbsShellTerminalSessionClient.onPasteTextFromClipboard(null);
        } else {
            super.onTerminalExtraKeyButtonClick(view, key, ctrlDown, altDown, shiftDown, fnDown);
        }
    }

}
