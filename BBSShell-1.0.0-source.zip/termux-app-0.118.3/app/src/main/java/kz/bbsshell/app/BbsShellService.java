package kz.bbsshell.app;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.ArrayAdapter;

import androidx.annotation.Nullable;

import kz.bbsshell.app.R;
import kz.bbsshell.app.settings.properties.BbsShellAppSharedProperties;
import kz.bbsshell.app.terminal.BbsShellTerminalSessionClient;
import kz.bbsshell.app.utils.PluginUtils;
import kz.bbsshell.shared.data.IntentUtils;
import kz.bbsshell.shared.models.errors.Errno;
import kz.bbsshell.shared.shell.ShellUtils;
import kz.bbsshell.shared.shell.BbsShellShellEnvironmentClient;
import kz.bbsshell.shared.shell.BbsShellShellUtils;
import kz.bbsshell.shared.core.BbsShellConstants;
import kz.bbsshell.shared.core.BbsShellConstants.BBSSHELL_APP.BBSSHELL_ACTIVITY;
import kz.bbsshell.shared.core.BbsShellConstants.BBSSHELL_APP.BBSSHELL_SERVICE;
import kz.bbsshell.shared.settings.preferences.BbsShellAppSharedPreferences;
import kz.bbsshell.shared.shell.BbsShellSession;
import kz.bbsshell.shared.terminal.BbsShellTerminalSessionClientBase;
import kz.bbsshell.shared.logger.Logger;
import kz.bbsshell.shared.notification.NotificationUtils;
import kz.bbsshell.shared.packages.PermissionUtils;
import kz.bbsshell.shared.data.DataUtils;
import kz.bbsshell.shared.models.ExecutionCommand;
import kz.bbsshell.shared.shell.BbsShellTask;
import kz.bbsshell.terminal.TerminalEmulator;
import kz.bbsshell.terminal.TerminalSession;
import kz.bbsshell.terminal.TerminalSessionClient;

import java.util.ArrayList;
import java.util.List;

/**
 * A service holding a list of {@link BbsShellSession} in {@link #mBbsShellSessions} and background {@link BbsShellTask}
 * in {@link #mBbsShellTasks}, showing a foreground notification while running so that it is not terminated.
 * The user interacts with the session through {@link BbsShellActivity}, but this service may outlive
 * the activity when the user or the system disposes of the activity. In that case the user may
 * restart {@link BbsShellActivity} later to yet again access the sessions.
 * <p/>
 * In order to keep both terminal sessions and spawned processes (who may outlive the terminal sessions) alive as long
 * as wanted by the user this service is a foreground service, {@link Service#startForeground(int, Notification)}.
 * <p/>
 * Optionally may hold a wake and a wifi lock, in which case that is shown in the notification - see
 * {@link #buildNotification()}.
 */
public final class BbsShellService extends Service implements BbsShellTask.BbsShellTaskClient, BbsShellSession.BbsShellSessionClient {

    private static int EXECUTION_ID = 1000;

    /** This service is only bound from inside the same process and never uses IPC. */
    class LocalBinder extends Binder {
        public final BbsShellService service = BbsShellService.this;
    }

    private final IBinder mBinder = new LocalBinder();

    private final Handler mHandler = new Handler();

    /**
     * The foreground BbsShellSessions which this service manages.
     * Note that this list is observed by {@link BbsShellActivity#mBbsShellSessionListViewController},
     * so any changes must be made on the UI thread and followed by a call to
     * {@link ArrayAdapter#notifyDataSetChanged()} }.
     */
    final List<BbsShellSession> mBbsShellSessions = new ArrayList<>();

    /**
     * The background BbsShellTasks which this service manages.
     */
    final List<BbsShellTask> mBbsShellTasks = new ArrayList<>();

    /**
     * The pending plugin ExecutionCommands that have yet to be processed by this service.
     */
    final List<ExecutionCommand> mPendingPluginExecutionCommands = new ArrayList<>();

    /** The full implementation of the {@link TerminalSessionClient} interface to be used by {@link TerminalSession}
     * that holds activity references for activity related functions.
     * Note that the service may often outlive the activity, so need to clear this reference.
     */
    BbsShellTerminalSessionClient mBbsShellTerminalSessionClient;

    /** The basic implementation of the {@link TerminalSessionClient} interface to be used by {@link TerminalSession}
     * that does not hold activity references.
     */
    final BbsShellTerminalSessionClientBase mBbsShellTerminalSessionClientBase = new BbsShellTerminalSessionClientBase();

    /** The wake lock and wifi lock are always acquired and released together. */
    private PowerManager.WakeLock mWakeLock;
    private WifiManager.WifiLock mWifiLock;

    /** If the user has executed the {@link BBSSHELL_SERVICE#ACTION_STOP_SERVICE} intent. */
    boolean mWantsToStop = false;

    public Integer mTerminalTranscriptRows;

    private static final String LOG_TAG = "BbsShellService";

    @Override
    public void onCreate() {
        Logger.logVerbose(LOG_TAG, "onCreate");
        runStartForeground();
    }

    @SuppressLint("Wakelock")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Logger.logDebug(LOG_TAG, "onStartCommand");

        // Run again in case service is already started and onCreate() is not called
        runStartForeground();

        String action = intent.getAction();

        if (action != null) {
            switch (action) {
                case BBSSHELL_SERVICE.ACTION_STOP_SERVICE:
                    Logger.logDebug(LOG_TAG, "ACTION_STOP_SERVICE intent received");
                    actionStopService();
                    break;
                case BBSSHELL_SERVICE.ACTION_WAKE_LOCK:
                    Logger.logDebug(LOG_TAG, "ACTION_WAKE_LOCK intent received");
                    actionAcquireWakeLock();
                    break;
                case BBSSHELL_SERVICE.ACTION_WAKE_UNLOCK:
                    Logger.logDebug(LOG_TAG, "ACTION_WAKE_UNLOCK intent received");
                    actionReleaseWakeLock(true);
                    break;
                case BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE:
                    Logger.logDebug(LOG_TAG, "ACTION_SERVICE_EXECUTE intent received");
                    actionServiceExecute(intent);
                    break;
                default:
                    Logger.logError(LOG_TAG, "Invalid action: \"" + action + "\"");
                    break;
            }
        }

        // If this service really do get killed, there is no point restarting it automatically - let the user do on next
        // start of {@link Term):
        return Service.START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        Logger.logVerbose(LOG_TAG, "onDestroy");

        BbsShellShellUtils.clearBbsShellTMPDIR(true);

        actionReleaseWakeLock(false);
        if (!mWantsToStop)
            killAllBbsShellExecutionCommands();
        runStopForeground();
    }

    @Override
    public IBinder onBind(Intent intent) {
        Logger.logVerbose(LOG_TAG, "onBind");
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Logger.logVerbose(LOG_TAG, "onUnbind");

        // Since we cannot rely on {@link BbsShellActivity.onDestroy()} to always complete,
        // we unset clients here as well if it failed, so that we do not leave service and session
        // clients with references to the activity.
        if (mBbsShellTerminalSessionClient != null)
            unsetBbsShellTerminalSessionClient();
        return false;
    }

    /** Make service run in foreground mode. */
    private void runStartForeground() {
        setupNotificationChannel();
        startForeground(BbsShellConstants.BBSSHELL_APP_NOTIFICATION_ID, buildNotification());
    }

    /** Make service leave foreground mode. */
    private void runStopForeground() {
        stopForeground(true);
    }

    /** Request to stop service. */
    private void requestStopService() {
        Logger.logDebug(LOG_TAG, "Requesting to stop service");
        runStopForeground();
        stopSelf();
    }

    /** Process action to stop service. */
    private void actionStopService() {
        mWantsToStop = true;
        killAllBbsShellExecutionCommands();
        requestStopService();
    }

    /** Kill all BbsShellSessions and BbsShellTasks by sending SIGKILL to their processes.
     *
     * For BbsShellSessions, all sessions will be killed, whether user manually exited BbsShell or if
     * onDestroy() was directly called because of unintended shutdown. The processing of results
     * will only be done if user manually exited bbsshell or if the session was started by a plugin
     * which **expects** the result back via a pending intent.
     *
     * For BbsShellTasks, only tasks that were started by a plugin which **expects** the result
     * back via a pending intent will be killed, whether user manually exited BbsShell or if
     * onDestroy() was directly called because of unintended shutdown. The processing of results
     * will always be done for the tasks that are killed. The remaining processes will keep on
     * running until the bbsshell app process is killed by android, like by OOM, so we let them run
     * as long as they can.
     *
     * Some plugin execution commands may not have been processed and added to mBbsShellSessions and
     * mBbsShellTasks lists before the service is killed, so we maintain a separate
     * mPendingPluginExecutionCommands list for those, so that we can notify the pending intent
     * creators that execution was cancelled.
     *
     * Note that if user didn't manually exit BbsShell and if onDestroy() was directly called because
     * of unintended shutdown, like android deciding to kill the service, then there will be no
     * guarantee that onDestroy() will be allowed to finish and bbsshell app process may be killed before
     * it has finished. This means that in those cases some results may not be sent back to their
     * creators for plugin commands but we still try to process whatever results can be processed
     * despite the unreliable behaviour of onDestroy().
     *
     * Note that if don't kill the processes started by plugins which **expect** the result back
     * and notify their creators that they have been killed, then they may get stuck waiting for
     * the results forever like in case of commands started by RUN_COMMAND intent,
     * since once BbsShellService has been killed, no result will be sent back. They may still get
     * stuck if bbsshell app process gets killed, so for this case reasonable timeout values should
     * be used.
     *
     * We make copies of each list since items are removed inside the loop.
     */
    private synchronized void killAllBbsShellExecutionCommands() {
        boolean processResult;

        Logger.logDebug(LOG_TAG, "Killing BbsShellSessions=" + mBbsShellSessions.size() + ", BbsShellTasks=" + mBbsShellTasks.size() + ", PendingPluginExecutionCommands=" + mPendingPluginExecutionCommands.size());

        List<BbsShellSession> bbsshellSessions = new ArrayList<>(mBbsShellSessions);
        for (int i = 0; i < bbsshellSessions.size(); i++) {
            ExecutionCommand executionCommand = bbsshellSessions.get(i).getExecutionCommand();
            processResult = mWantsToStop || executionCommand.isPluginExecutionCommandWithPendingResult();
            bbsshellSessions.get(i).killIfExecuting(this, processResult);
        }

        List<BbsShellTask> bbsshellTasks = new ArrayList<>(mBbsShellTasks);
        for (int i = 0; i < bbsshellTasks.size(); i++) {
            ExecutionCommand executionCommand = bbsshellTasks.get(i).getExecutionCommand();
            if (executionCommand.isPluginExecutionCommandWithPendingResult())
                bbsshellTasks.get(i).killIfExecuting(this, true);
        }

        List<ExecutionCommand> pendingPluginExecutionCommands = new ArrayList<>(mPendingPluginExecutionCommands);
        for (int i = 0; i < pendingPluginExecutionCommands.size(); i++) {
            ExecutionCommand executionCommand = pendingPluginExecutionCommands.get(i);
            if (!executionCommand.shouldNotProcessResults() && executionCommand.isPluginExecutionCommandWithPendingResult()) {
                if (executionCommand.setStateFailed(Errno.ERRNO_CANCELLED.getCode(), this.getString(kz.bbsshell.shared.R.string.error_execution_cancelled))) {
                    PluginUtils.processPluginExecutionCommandResult(this, LOG_TAG, executionCommand);
                }
            }
        }
    }



    /** Process action to acquire Power and Wi-Fi WakeLocks. */
    @SuppressLint({"WakelockTimeout", "BatteryLife"})
    private void actionAcquireWakeLock() {
        if (mWakeLock != null) {
            Logger.logDebug(LOG_TAG, "Ignoring acquiring WakeLocks since they are already held");
            return;
        }

        Logger.logDebug(LOG_TAG, "Acquiring WakeLocks");

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, BbsShellConstants.BBSSHELL_APP_NAME.toLowerCase() + ":service-wakelock");
        mWakeLock.acquire();

        // http://tools.android.com/tech-docs/lint-in-studio-2-3#TOC-WifiManager-Leak
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        mWifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, BbsShellConstants.BBSSHELL_APP_NAME.toLowerCase());
        mWifiLock.acquire();

        String packageName = getPackageName();
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            Intent whitelist = new Intent();
            whitelist.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            whitelist.setData(Uri.parse("package:" + packageName));
            whitelist.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            try {
                startActivity(whitelist);
            } catch (ActivityNotFoundException e) {
                Logger.logStackTraceWithMessage(LOG_TAG, "Failed to call ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", e);
            }
        }

        updateNotification();

        Logger.logDebug(LOG_TAG, "WakeLocks acquired successfully");

    }

    /** Process action to release Power and Wi-Fi WakeLocks. */
    private void actionReleaseWakeLock(boolean updateNotification) {
        if (mWakeLock == null && mWifiLock == null) {
            Logger.logDebug(LOG_TAG, "Ignoring releasing WakeLocks since none are already held");
            return;
        }

        Logger.logDebug(LOG_TAG, "Releasing WakeLocks");

        if (mWakeLock != null) {
            mWakeLock.release();
            mWakeLock = null;
        }

        if (mWifiLock != null) {
            mWifiLock.release();
            mWifiLock = null;
        }

        if (updateNotification)
            updateNotification();

        Logger.logDebug(LOG_TAG, "WakeLocks released successfully");
    }

    /** Process {@link BBSSHELL_SERVICE#ACTION_SERVICE_EXECUTE} intent to execute a shell command in
     * a foreground BbsShellSession or in a background BbsShellTask. */
    private void actionServiceExecute(Intent intent) {
        if (intent == null) {
            Logger.logError(LOG_TAG, "Ignoring null intent to actionServiceExecute");
            return;
        }

        ExecutionCommand executionCommand = new ExecutionCommand(getNextExecutionId());

        executionCommand.executableUri = intent.getData();
        executionCommand.inBackground = intent.getBooleanExtra(BBSSHELL_SERVICE.EXTRA_BACKGROUND, false);

        if (executionCommand.executableUri != null) {
            executionCommand.executable = executionCommand.executableUri.getPath();
            executionCommand.arguments = IntentUtils.getStringArrayExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_ARGUMENTS, null);
            if (executionCommand.inBackground)
                executionCommand.stdin = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_STDIN, null);
                executionCommand.backgroundCustomLogLevel = IntentUtils.getIntegerExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_BACKGROUND_CUSTOM_LOG_LEVEL, null);
        }

        executionCommand.workingDirectory = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_WORKDIR, null);
        executionCommand.isFailsafe = intent.getBooleanExtra(BBSSHELL_ACTIVITY.EXTRA_FAILSAFE_SESSION, false);
        executionCommand.sessionAction = intent.getStringExtra(BBSSHELL_SERVICE.EXTRA_SESSION_ACTION);
        executionCommand.commandLabel = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_COMMAND_LABEL, "Execution Intent Command");
        executionCommand.commandDescription = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_COMMAND_DESCRIPTION, null);
        executionCommand.commandHelp = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_COMMAND_HELP, null);
        executionCommand.pluginAPIHelp = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_PLUGIN_API_HELP, null);
        executionCommand.isPluginExecutionCommand = true;
        executionCommand.resultConfig.resultPendingIntent = intent.getParcelableExtra(BBSSHELL_SERVICE.EXTRA_PENDING_INTENT);
        executionCommand.resultConfig.resultDirectoryPath = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_RESULT_DIRECTORY, null);
        if (executionCommand.resultConfig.resultDirectoryPath != null) {
            executionCommand.resultConfig.resultSingleFile = intent.getBooleanExtra(BBSSHELL_SERVICE.EXTRA_RESULT_SINGLE_FILE, false);
            executionCommand.resultConfig.resultFileBasename = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_RESULT_FILE_BASENAME, null);
            executionCommand.resultConfig.resultFileOutputFormat = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_RESULT_FILE_OUTPUT_FORMAT, null);
            executionCommand.resultConfig.resultFileErrorFormat = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_RESULT_FILE_ERROR_FORMAT, null);
            executionCommand.resultConfig.resultFilesSuffix = IntentUtils.getStringExtraIfSet(intent, BBSSHELL_SERVICE.EXTRA_RESULT_FILES_SUFFIX, null);
        }

        // Add the execution command to pending plugin execution commands list
        mPendingPluginExecutionCommands.add(executionCommand);

        if (executionCommand.inBackground) {
            executeBbsShellTaskCommand(executionCommand);
        } else {
            executeBbsShellSessionCommand(executionCommand);
        }
    }





    /** Execute a shell command in background {@link BbsShellTask}. */
    private void executeBbsShellTaskCommand(ExecutionCommand executionCommand) {
        if (executionCommand == null) return;

        Logger.logDebug(LOG_TAG, "Executing background \"" + executionCommand.getCommandIdAndLabelLogString() + "\" BbsShellTask command");

        BbsShellTask newBbsShellTask = createBbsShellTask(executionCommand);
    }

    /** Create a {@link BbsShellTask}. */
    @Nullable
    public BbsShellTask createBbsShellTask(String executablePath, String[] arguments, String stdin, String workingDirectory) {
        return createBbsShellTask(new ExecutionCommand(getNextExecutionId(), executablePath, arguments, stdin, workingDirectory, true, false));
    }

    /** Create a {@link BbsShellTask}. */
    @Nullable
    public synchronized BbsShellTask createBbsShellTask(ExecutionCommand executionCommand) {
        if (executionCommand == null) return null;

        Logger.logDebug(LOG_TAG, "Creating \"" + executionCommand.getCommandIdAndLabelLogString() + "\" BbsShellTask");

        if (!executionCommand.inBackground) {
            Logger.logDebug(LOG_TAG, "Ignoring a foreground execution command passed to createBbsShellTask()");
            return null;
        }

        if (Logger.getLogLevel() >= Logger.LOG_LEVEL_VERBOSE)
            Logger.logVerboseExtended(LOG_TAG, executionCommand.toString());

        BbsShellTask newBbsShellTask = BbsShellTask.execute(this, executionCommand, this, new BbsShellShellEnvironmentClient(), false);
        if (newBbsShellTask == null) {
            Logger.logError(LOG_TAG, "Failed to execute new BbsShellTask command for:\n" + executionCommand.getCommandIdAndLabelLogString());
            // If the execution command was started for a plugin, then process the error
            if (executionCommand.isPluginExecutionCommand)
                PluginUtils.processPluginExecutionCommandError(this, LOG_TAG, executionCommand, false);
            else
                Logger.logErrorExtended(LOG_TAG, executionCommand.toString());
            return null;
        }

        mBbsShellTasks.add(newBbsShellTask);

        // Remove the execution command from the pending plugin execution commands list since it has
        // now been processed
        if (executionCommand.isPluginExecutionCommand)
            mPendingPluginExecutionCommands.remove(executionCommand);

        updateNotification();

        return newBbsShellTask;
    }

    /** Callback received when a {@link BbsShellTask} finishes. */
    @Override
    public void onBbsShellTaskExited(final BbsShellTask bbsshellTask) {
        mHandler.post(() -> {
            if (bbsshellTask != null) {
                ExecutionCommand executionCommand = bbsshellTask.getExecutionCommand();

                Logger.logVerbose(LOG_TAG, "The onBbsShellTaskExited() callback called for \"" + executionCommand.getCommandIdAndLabelLogString() + "\" BbsShellTask command");

                // If the execution command was started for a plugin, then process the results
                if (executionCommand != null && executionCommand.isPluginExecutionCommand)
                    PluginUtils.processPluginExecutionCommandResult(this, LOG_TAG, executionCommand);

                mBbsShellTasks.remove(bbsshellTask);
            }

            updateNotification();
        });
    }





    /** Execute a shell command in a foreground {@link BbsShellSession}. */
    private void executeBbsShellSessionCommand(ExecutionCommand executionCommand) {
        if (executionCommand == null) return;

        Logger.logDebug(LOG_TAG, "Executing foreground \"" + executionCommand.getCommandIdAndLabelLogString() + "\" BbsShellSession command");

        String sessionName = null;

        // Transform executable path to session name, e.g. "/bin/do-something.sh" => "do something.sh".
        if (executionCommand.executable != null) {
            sessionName = ShellUtils.getExecutableBasename(executionCommand.executable).replace('-', ' ');
        }

        BbsShellSession newBbsShellSession = createBbsShellSession(executionCommand, sessionName);
        if (newBbsShellSession == null) return;

        handleSessionAction(DataUtils.getIntFromString(executionCommand.sessionAction,
            BBSSHELL_SERVICE.VALUE_EXTRA_SESSION_ACTION_SWITCH_TO_NEW_SESSION_AND_OPEN_ACTIVITY),
            newBbsShellSession.getTerminalSession());
    }

    /**
     * Create a {@link BbsShellSession}.
     * Currently called by {@link BbsShellTerminalSessionClient#addNewSession(boolean, String)} to add a new {@link BbsShellSession}.
     */
    @Nullable
    public BbsShellSession createBbsShellSession(String executablePath, String[] arguments, String stdin, String workingDirectory, boolean isFailSafe, String sessionName) {
        return createBbsShellSession(new ExecutionCommand(getNextExecutionId(), executablePath, arguments, stdin, workingDirectory, false, isFailSafe), sessionName);
    }

    /** Create a {@link BbsShellSession}. */
    @Nullable
    public synchronized BbsShellSession createBbsShellSession(ExecutionCommand executionCommand, String sessionName) {
        if (executionCommand == null) return null;

        Logger.logDebug(LOG_TAG, "Creating \"" + executionCommand.getCommandIdAndLabelLogString() + "\" BbsShellSession");

        if (executionCommand.inBackground) {
            Logger.logDebug(LOG_TAG, "Ignoring a background execution command passed to createBbsShellSession()");
            return null;
        }

        if (Logger.getLogLevel() >= Logger.LOG_LEVEL_VERBOSE)
            Logger.logVerboseExtended(LOG_TAG, executionCommand.toString());

        // If the execution command was started for a plugin, only then will the stdout be set
        // Otherwise if command was manually started by the user like by adding a new terminal session,
        // then no need to set stdout
        executionCommand.terminalTranscriptRows = getTerminalTranscriptRows();
        BbsShellSession newBbsShellSession = BbsShellSession.execute(this, executionCommand, getBbsShellTerminalSessionClient(), this, new BbsShellShellEnvironmentClient(), sessionName, executionCommand.isPluginExecutionCommand);
        if (newBbsShellSession == null) {
            Logger.logError(LOG_TAG, "Failed to execute new BbsShellSession command for:\n" + executionCommand.getCommandIdAndLabelLogString());
            // If the execution command was started for a plugin, then process the error
            if (executionCommand.isPluginExecutionCommand)
                PluginUtils.processPluginExecutionCommandError(this, LOG_TAG, executionCommand, false);
            else
                Logger.logErrorExtended(LOG_TAG, executionCommand.toString());
            return null;
        }

        mBbsShellSessions.add(newBbsShellSession);

        // Remove the execution command from the pending plugin execution commands list since it has
        // now been processed
        if (executionCommand.isPluginExecutionCommand)
            mPendingPluginExecutionCommands.remove(executionCommand);

        // Notify {@link BbsShellSessionsListViewController} that sessions list has been updated if
        // activity in is foreground
        if (mBbsShellTerminalSessionClient != null)
            mBbsShellTerminalSessionClient.bbsshellSessionListNotifyUpdated();

        updateNotification();
        BbsShellActivity.updateBbsShellActivityStyling(this);

        return newBbsShellSession;
    }

    /** Remove a BbsShellSession. */
    public synchronized int removeBbsShellSession(TerminalSession sessionToRemove) {
        int index = getIndexOfSession(sessionToRemove);

        if (index >= 0)
            mBbsShellSessions.get(index).finish();

        return index;
    }

    /** Callback received when a {@link BbsShellSession} finishes. */
    @Override
    public void onBbsShellSessionExited(final BbsShellSession bbsshellSession) {
        if (bbsshellSession != null) {
            ExecutionCommand executionCommand = bbsshellSession.getExecutionCommand();

            Logger.logVerbose(LOG_TAG, "The onBbsShellSessionExited() callback called for \"" + executionCommand.getCommandIdAndLabelLogString() + "\" BbsShellSession command");

            // If the execution command was started for a plugin, then process the results
            if (executionCommand != null && executionCommand.isPluginExecutionCommand)
                PluginUtils.processPluginExecutionCommandResult(this, LOG_TAG, executionCommand);

            mBbsShellSessions.remove(bbsshellSession);

            // Notify {@link BbsShellSessionsListViewController} that sessions list has been updated if
            // activity in is foreground
            if (mBbsShellTerminalSessionClient != null)
                mBbsShellTerminalSessionClient.bbsshellSessionListNotifyUpdated();
        }

        updateNotification();
    }

    /** Get the terminal transcript rows to be used for new {@link BbsShellSession}. */
    public Integer getTerminalTranscriptRows() {
        if (mTerminalTranscriptRows == null)
            setTerminalTranscriptRows();
        return mTerminalTranscriptRows;
    }

    public void setTerminalTranscriptRows() {
        // BbsShellService only uses this bbsshell property currently, so no need to load them all into
        // an internal values map like BbsShellActivity does
        mTerminalTranscriptRows = BbsShellAppSharedProperties.getTerminalTranscriptRows(this);
    }





    /** Process session action for new session. */
    private void handleSessionAction(int sessionAction, TerminalSession newTerminalSession) {
        Logger.logDebug(LOG_TAG, "Processing sessionAction \"" + sessionAction + "\" for session \"" + newTerminalSession.mSessionName + "\"");

        switch (sessionAction) {
            case BBSSHELL_SERVICE.VALUE_EXTRA_SESSION_ACTION_SWITCH_TO_NEW_SESSION_AND_OPEN_ACTIVITY:
                setCurrentStoredTerminalSession(newTerminalSession);
                if (mBbsShellTerminalSessionClient != null)
                    mBbsShellTerminalSessionClient.setCurrentSession(newTerminalSession);
                startBbsShellActivity();
                break;
            case BBSSHELL_SERVICE.VALUE_EXTRA_SESSION_ACTION_KEEP_CURRENT_SESSION_AND_OPEN_ACTIVITY:
                if (getBbsShellSessionsSize() == 1)
                    setCurrentStoredTerminalSession(newTerminalSession);
                startBbsShellActivity();
                break;
            case BBSSHELL_SERVICE.VALUE_EXTRA_SESSION_ACTION_SWITCH_TO_NEW_SESSION_AND_DONT_OPEN_ACTIVITY:
                setCurrentStoredTerminalSession(newTerminalSession);
                if (mBbsShellTerminalSessionClient != null)
                    mBbsShellTerminalSessionClient.setCurrentSession(newTerminalSession);
                break;
            case BBSSHELL_SERVICE.VALUE_EXTRA_SESSION_ACTION_KEEP_CURRENT_SESSION_AND_DONT_OPEN_ACTIVITY:
                if (getBbsShellSessionsSize() == 1)
                    setCurrentStoredTerminalSession(newTerminalSession);
                break;
            default:
                Logger.logError(LOG_TAG, "Invalid sessionAction: \"" + sessionAction + "\". Force using default sessionAction.");
                handleSessionAction(BBSSHELL_SERVICE.VALUE_EXTRA_SESSION_ACTION_SWITCH_TO_NEW_SESSION_AND_OPEN_ACTIVITY, newTerminalSession);
                break;
        }
    }

    /** Launch the {@link }BbsShellActivity} to bring it to foreground. */
    private void startBbsShellActivity() {
        // For android >= 10, apps require Display over other apps permission to start foreground activities
        // from background (services). If it is not granted, then BbsShellSessions that are started will
        // show in BbsShell notification but will not run until user manually clicks the notification.
        if (PermissionUtils.validateDisplayOverOtherAppsPermissionForPostAndroid10(this, true)) {
            BbsShellActivity.startBbsShellActivity(this);
        } else {
            BbsShellAppSharedPreferences preferences = BbsShellAppSharedPreferences.build(this);
            if (preferences == null) return;
            if (preferences.arePluginErrorNotificationsEnabled())
                Logger.showToast(this, this.getString(R.string.error_display_over_other_apps_permission_not_granted), true);
        }
    }





    /** If {@link BbsShellActivity} has not bound to the {@link BbsShellService} yet or is destroyed, then
     * interface functions requiring the activity should not be available to the terminal sessions,
     * so we just return the {@link #mBbsShellTerminalSessionClientBase}. Once {@link BbsShellActivity} bind
     * callback is received, it should call {@link #setBbsShellTerminalSessionClient} to set the
     * {@link BbsShellService#mBbsShellTerminalSessionClient} so that further terminal sessions are directly
     * passed the {@link BbsShellTerminalSessionClient} object which fully implements the
     * {@link TerminalSessionClient} interface.
     *
     * @return Returns the {@link BbsShellTerminalSessionClient} if {@link BbsShellActivity} has bound with
     * {@link BbsShellService}, otherwise {@link BbsShellTerminalSessionClientBase}.
     */
    public synchronized BbsShellTerminalSessionClientBase getBbsShellTerminalSessionClient() {
        if (mBbsShellTerminalSessionClient != null)
            return mBbsShellTerminalSessionClient;
        else
            return mBbsShellTerminalSessionClientBase;
    }

    /** This should be called when {@link BbsShellActivity#onServiceConnected} is called to set the
     * {@link BbsShellService#mBbsShellTerminalSessionClient} variable and update the {@link TerminalSession}
     * and {@link TerminalEmulator} clients in case they were passed {@link BbsShellTerminalSessionClientBase}
     * earlier.
     *
     * @param bbsshellTerminalSessionClient The {@link BbsShellTerminalSessionClient} object that fully
     * implements the {@link TerminalSessionClient} interface.
     */
    public synchronized void setBbsShellTerminalSessionClient(BbsShellTerminalSessionClient bbsshellTerminalSessionClient) {
        mBbsShellTerminalSessionClient = bbsshellTerminalSessionClient;

        for (int i = 0; i < mBbsShellSessions.size(); i++)
            mBbsShellSessions.get(i).getTerminalSession().updateTerminalSessionClient(mBbsShellTerminalSessionClient);
    }

    /** This should be called when {@link BbsShellActivity} has been destroyed and in {@link #onUnbind(Intent)}
     * so that the {@link BbsShellService} and {@link TerminalSession} and {@link TerminalEmulator}
     * clients do not hold an activity references.
     */
    public synchronized void unsetBbsShellTerminalSessionClient() {
        for (int i = 0; i < mBbsShellSessions.size(); i++)
            mBbsShellSessions.get(i).getTerminalSession().updateTerminalSessionClient(mBbsShellTerminalSessionClientBase);

        mBbsShellTerminalSessionClient = null;
    }





    private Notification buildNotification() {
        Resources res = getResources();

        // Set pending intent to be launched when notification is clicked
        Intent notificationIntent = BbsShellActivity.newInstance(this);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);


        // Set notification text
        int sessionCount = getBbsShellSessionsSize();
        int taskCount = mBbsShellTasks.size();
        String notificationText = sessionCount + " session" + (sessionCount == 1 ? "" : "s");
        if (taskCount > 0) {
            notificationText += ", " + taskCount + " task" + (taskCount == 1 ? "" : "s");
        }

        final boolean wakeLockHeld = mWakeLock != null;
        if (wakeLockHeld) notificationText += " (wake lock held)";


        // Set notification priority
        // If holding a wake or wifi lock consider the notification of high priority since it's using power,
        // otherwise use a low priority
        int priority = (wakeLockHeld) ? Notification.PRIORITY_HIGH : Notification.PRIORITY_LOW;


        // Build the notification
        Notification.Builder builder =  NotificationUtils.geNotificationBuilder(this,
            BbsShellConstants.BBSSHELL_APP_NOTIFICATION_CHANNEL_ID, priority,
            BbsShellConstants.BBSSHELL_APP_NAME, notificationText, null,
            contentIntent, null, NotificationUtils.NOTIFICATION_MODE_SILENT);
        if (builder == null)  return null;

        // No need to show a timestamp:
        builder.setShowWhen(false);

        // Set notification icon
        builder.setSmallIcon(R.drawable.ic_service_notification);

        // Set background color for small notification icon
        builder.setColor(0xFF607D8B);

        // BbsShellSessions are always ongoing
        builder.setOngoing(true);


        // Set Exit button action
        Intent exitIntent = new Intent(this, BbsShellService.class).setAction(BBSSHELL_SERVICE.ACTION_STOP_SERVICE);
        builder.addAction(android.R.drawable.ic_delete, res.getString(R.string.notification_action_exit), PendingIntent.getService(this, 0, exitIntent, 0));


        // Set Wakelock button actions
        String newWakeAction = wakeLockHeld ? BBSSHELL_SERVICE.ACTION_WAKE_UNLOCK : BBSSHELL_SERVICE.ACTION_WAKE_LOCK;
        Intent toggleWakeLockIntent = new Intent(this, BbsShellService.class).setAction(newWakeAction);
        String actionTitle = res.getString(wakeLockHeld ? R.string.notification_action_wake_unlock : R.string.notification_action_wake_lock);
        int actionIcon = wakeLockHeld ? android.R.drawable.ic_lock_idle_lock : android.R.drawable.ic_lock_lock;
        builder.addAction(actionIcon, actionTitle, PendingIntent.getService(this, 0, toggleWakeLockIntent, 0));


        return builder.build();
    }

    private void setupNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationUtils.setupNotificationChannel(this, BbsShellConstants.BBSSHELL_APP_NOTIFICATION_CHANNEL_ID,
            BbsShellConstants.BBSSHELL_APP_NOTIFICATION_CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW);
    }

    /** Update the shown foreground service notification after making any changes that affect it. */
    private synchronized void updateNotification() {
        if (mWakeLock == null && mBbsShellSessions.isEmpty() && mBbsShellTasks.isEmpty()) {
            // Exit if we are updating after the user disabled all locks with no sessions or tasks running.
            requestStopService();
        } else {
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(BbsShellConstants.BBSSHELL_APP_NOTIFICATION_ID, buildNotification());
        }
    }





    private void setCurrentStoredTerminalSession(TerminalSession session) {
        if (session == null) return;
        // Make the newly created session the current one to be displayed
        BbsShellAppSharedPreferences preferences = BbsShellAppSharedPreferences.build(this);
        if (preferences == null) return;
        preferences.setCurrentSession(session.mHandle);
    }

    public synchronized boolean isBbsShellSessionsEmpty() {
        return mBbsShellSessions.isEmpty();
    }

    public synchronized int getBbsShellSessionsSize() {
        return mBbsShellSessions.size();
    }

    public synchronized List<BbsShellSession> getBbsShellSessions() {
        return mBbsShellSessions;
    }

    @Nullable
    public synchronized BbsShellSession getBbsShellSession(int index) {
        if (index >= 0 && index < mBbsShellSessions.size())
            return mBbsShellSessions.get(index);
        else
            return null;
    }

    public synchronized BbsShellSession getLastBbsShellSession() {
        return mBbsShellSessions.isEmpty() ? null : mBbsShellSessions.get(mBbsShellSessions.size() - 1);
    }

    public synchronized int getIndexOfSession(TerminalSession terminalSession) {
        for (int i = 0; i < mBbsShellSessions.size(); i++) {
            if (mBbsShellSessions.get(i).getTerminalSession().equals(terminalSession))
                return i;
        }
        return -1;
    }

    public synchronized TerminalSession getTerminalSessionForHandle(String sessionHandle) {
        TerminalSession terminalSession;
        for (int i = 0, len = mBbsShellSessions.size(); i < len; i++) {
            terminalSession = mBbsShellSessions.get(i).getTerminalSession();
            if (terminalSession.mHandle.equals(sessionHandle))
                return terminalSession;
        }
        return null;
    }



    public static synchronized int getNextExecutionId() {
        return EXECUTION_ID++;
    }

    public boolean wantsToStop() {
        return mWantsToStop;
    }

}
