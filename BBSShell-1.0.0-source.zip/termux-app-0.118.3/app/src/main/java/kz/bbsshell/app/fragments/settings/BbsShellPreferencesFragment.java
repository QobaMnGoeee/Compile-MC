package kz.bbsshell.app.fragments.settings;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Keep;
import androidx.preference.PreferenceDataStore;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceManager;

import kz.bbsshell.app.R;
import kz.bbsshell.shared.settings.preferences.BbsShellAppSharedPreferences;

@Keep
public class BbsShellPreferencesFragment extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        Context context = getContext();
        if (context == null) return;

        PreferenceManager preferenceManager = getPreferenceManager();
        preferenceManager.setPreferenceDataStore(BbsShellPreferencesDataStore.getInstance(context));

        setPreferencesFromResource(R.xml.bbsshell_preferences, rootKey);
    }

}

class BbsShellPreferencesDataStore extends PreferenceDataStore {

    private final Context mContext;
    private final BbsShellAppSharedPreferences mPreferences;

    private static BbsShellPreferencesDataStore mInstance;

    private BbsShellPreferencesDataStore(Context context) {
        mContext = context;
        mPreferences = BbsShellAppSharedPreferences.build(context, true);
    }

    public static synchronized BbsShellPreferencesDataStore getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new BbsShellPreferencesDataStore(context);
        }
        return mInstance;
    }

}
