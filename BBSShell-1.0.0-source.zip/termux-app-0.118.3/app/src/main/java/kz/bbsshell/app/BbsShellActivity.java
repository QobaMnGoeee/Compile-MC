package kz.bbsshell.app;

import kz.bbsshell.app.theme.BbsShellTheme;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import kz.bbsshell.app.R;
import kz.bbsshell.app.terminal.BbsShellActivityRootView;
import kz.bbsshell.shared.activities.ReportActivity;
import kz.bbsshell.shared.packages.PermissionUtils;
import kz.bbsshell.shared.data.DataUtils;
import kz.bbsshell.shared.core.BbsShellConstants;
import kz.bbsshell.shared.core.BbsShellConstants.BBSSHELL_APP.BBSSHELL_ACTIVITY;
import kz.bbsshell.app.activities.HelpActivity;
import kz.bbsshell.app.activities.SettingsActivity;
import kz.bbsshell.shared.settings.preferences.BbsShellAppSharedPreferences;
import kz.bbsshell.app.terminal.BbsShellSessionsListViewController;
import kz.bbsshell.app.terminal.io.TerminalToolbarViewPager;
import kz.bbsshell.app.terminal.BbsShellTerminalSessionClient;
import kz.bbsshell.app.terminal.BbsShellTerminalViewClient;
import kz.bbsshell.shared.terminal.io.extrakeys.ExtraKeysView;
import kz.bbsshell.app.settings.properties.BbsShellAppSharedProperties;
import kz.bbsshell.shared.interact.TextInputDialogUtils;
import kz.bbsshell.shared.logger.Logger;
import kz.bbsshell.shared.core.BbsShellUtils;
import kz.bbsshell.shared.view.ViewUtils;
import kz.bbsshell.terminal.TerminalSession;
import kz.bbsshell.terminal.TerminalSessionClient;
import kz.bbsshell.app.utils.CrashUtils;
import kz.bbsshell.view.TerminalView;
import kz.bbsshell.view.TerminalViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

/**
 * A terminal emulator activity.
 * <p/>
 * See
 * <ul>
 * <li>http://www.mongrel-phones.com.au/default/how_to_make_a_local_service_and_bind_to_it_in_android</li>
 * <li>https://code.google.com/p/android/issues/detail?id=6426</li>
 * </ul>
 * about memory leaks.
 */
public final class BbsShellActivity extends Activity implements ServiceConnection {

    /**
     * The connection to the {@link BbsShellService}. Requested in {@link #onCreate(Bundle)} with a call to
     * {@link #bindService(Intent, ServiceConnection, int)}, and obtained and stored in
     * {@link #onServiceConnected(ComponentName, IBinder)}.
     */
    BbsShellService mBbsShellService;

    /**
     * The {@link TerminalView} shown in  {@link BbsShellActivity} that displays the terminal.
     */
    TerminalView mTerminalView;

    /**
     *  The {@link TerminalViewClient} interface implementation to allow for communication between
     *  {@link TerminalView} and {@link BbsShellActivity}.
     */
    BbsShellTerminalViewClient mBbsShellTerminalViewClient;

    /**
     *  The {@link TerminalSessionClient} interface implementation to allow for communication between
     *  {@link TerminalSession} and {@link BbsShellActivity}.
     */
    BbsShellTerminalSessionClient mBbsShellTerminalSessionClient;

    /**
     * BbsShell app shared preferences manager.
     */
    private BbsShellAppSharedPreferences mPreferences;

    /**
     * BbsShell app shared properties manager, loaded from bbsshell.properties
     */
    private BbsShellAppSharedProperties mProperties;

    /**
     * The root view of the {@link BbsShellActivity}.
     */
    BbsShellActivityRootView mBbsShellActivityRootView;

    /**
     * The space at the bottom of {@link @mBbsShellActivityRootView} of the {@link BbsShellActivity}.
     */
    View mBbsShellActivityBottomSpaceView;

    /**
     * The terminal extra keys view.
     */
    ExtraKeysView mExtraKeysView;

    /**
     * The bbsshell sessions list controller.
     */
    BbsShellSessionsListViewController mBbsShellSessionListViewController;

    /**
     * The {@link BbsShellActivity} broadcast receiver for various things like terminal style configuration changes.
     */
    private final BroadcastReceiver mBbsShellActivityBroadcastReceiver = new BbsShellActivityBroadcastReceiver();

    /**
     * The last toast shown, used cancel current toast before showing new in {@link #showToast(String, boolean)}.
     */
    Toast mLastToast;

    /**
     * If between onResume() and onStop(). Note that only one session is in the foreground of the terminal view at the
     * time, so if the session causing a change is not in the foreground it should probably be treated as background.
     */
    private boolean mIsVisible;

    /**
     * If onResume() was called after onCreate().
     */
    private boolean isOnResumeAfterOnCreate = false;

    /**
     * The {@link BbsShellActivity} is in an invalid state and must not be run.
     */
    private boolean mIsInvalidState;

    private int mNavBarHeight;

    private int mTerminalToolbarDefaultHeight;


    private static final int CONTEXT_MENU_SELECT_URL_ID = 0;
    private static final int CONTEXT_MENU_SHARE_TRANSCRIPT_ID = 1;
    private static final int CONTEXT_MENU_SHARE_SELECTED_TEXT = 10;
    private static final int CONTEXT_MENU_AUTOFILL_USERNAME = 11;
    private static final int CONTEXT_MENU_AUTOFILL_PASSWORD = 2;
    private static final int CONTEXT_MENU_RESET_TERMINAL_ID = 3;
    private static final int CONTEXT_MENU_KILL_PROCESS_ID = 4;
    private static final int CONTEXT_MENU_TOGGLE_KEEP_SCREEN_ON = 6;
    private static final int CONTEXT_MENU_HELP_ID = 7;
    private static final int CONTEXT_MENU_SETTINGS_ID = 8;
    private static final int CONTEXT_MENU_REPORT_ID = 9;

    private static final String ARG_TERMINAL_TOOLBAR_TEXT_INPUT = "terminal_toolbar_text_input";

    private static final String LOG_TAG = "BbsShellActivity";

    @Override
    public void onCreate(Bundle savedInstanceState) {

        Logger.logDebug(LOG_TAG, "onCreate");
        isOnResumeAfterOnCreate = true;

        // Check if a crash happened on last run of the app and show a
        // notification with the crash details if it did
        CrashUtils.notifyAppCrashOnLastRun(this, LOG_TAG);

        // Delete ReportInfo serialized object files from cache older than 14 days
        ReportActivity.deleteReportInfoFilesOlderThanXDays(this, 14, false);

        // Load bbsshell shared properties
        mProperties = new BbsShellAppSharedProperties(this);

        setActivityTheme();

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_bbsshell);

        // Load bbsshell shared preferences
        // This will also fail if BbsShellConstants.BBSSHELL_PACKAGE_NAME does not equal applicationId
        mPreferences = BbsShellAppSharedPreferences.build(this, true);
        if (mPreferences == null) {
            // An AlertDialog should have shown to kill the app, so we don't continue running activity code
            mIsInvalidState = true;
            return;
        }

        setMargins();

        mBbsShellActivityRootView = findViewById(R.id.activity_bbsshell_root_view);
        mBbsShellActivityRootView.setActivity(this);
        mBbsShellActivityBottomSpaceView = findViewById(R.id.activity_bbsshell_bottom_space_view);
        mBbsShellActivityRootView.setOnApplyWindowInsetsListener(new BbsShellActivityRootView.WindowInsetsListener());

        View content = findViewById(android.R.id.content);
        content.setOnApplyWindowInsetsListener((v, insets) -> {
            mNavBarHeight = insets.getSystemWindowInsetBottom();
            return insets;
        });

        if (mProperties.isUsingFullScreen()) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }

        setDrawerTheme();

        setBbsShellTerminalViewAndClients();

        setTerminalToolbarView(savedInstanceState);

        setSettingsButtonView();

        setNewSessionButtonView();

        setToggleKeyboardView();

        registerForContextMenu(mTerminalView);

        // Start the {@link BbsShellService} and make it run regardless of who is bound to it
        Intent serviceIntent = new Intent(this, BbsShellService.class);
        startService(serviceIntent);

        // Attempt to bind to the service, this will call the {@link #onServiceConnected(ComponentName, IBinder)}
        // callback if it succeeds.
        if (!bindService(serviceIntent, this, 0))
            throw new RuntimeException("bindService() failed");

        // Send the {@link BbsShellConstants#BROADCAST_BBSSHELL_OPENED} broadcast to notify apps that BbsShell
        // app has been opened.
        BbsShellUtils.sendBbsShellOpenedBroadcast(this);
    }

    @Override
    public void onStart() {
        super.onStart();

        Logger.logDebug(LOG_TAG, "onStart");

        if (mIsInvalidState) return;

        mIsVisible = true;

        if (mBbsShellTerminalSessionClient != null)
            mBbsShellTerminalSessionClient.onStart();

        if (mBbsShellTerminalViewClient != null)
            mBbsShellTerminalViewClient.onStart();

        if (mPreferences.isTerminalMarginAdjustmentEnabled())
            addBbsShellActivityRootViewGlobalLayoutListener();

        registerBbsShellActivityBroadcastReceiver();
    }

    @Override
    public void onResume() {
        super.onResume();

        Logger.logVerbose(LOG_TAG, "onResume");

        if (mIsInvalidState) return;

        if (mBbsShellTerminalSessionClient != null)
            mBbsShellTerminalSessionClient.onResume();

        if (mBbsShellTerminalViewClient != null)
            mBbsShellTerminalViewClient.onResume();

        isOnResumeAfterOnCreate = false;
    }

    @Override
    protected void onStop() {
        super.onStop();

        Logger.logDebug(LOG_TAG, "onStop");

        if (mIsInvalidState) return;

        mIsVisible = false;

        if (mBbsShellTerminalSessionClient != null)
            mBbsShellTerminalSessionClient.onStop();

        if (mBbsShellTerminalViewClient != null)
            mBbsShellTerminalViewClient.onStop();

        removeBbsShellActivityRootViewGlobalLayoutListener();

        unregisterBbsShellActivityBroadcastReceiever();
        getDrawer().closeDrawers();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        Logger.logDebug(LOG_TAG, "onDestroy");

        if (mIsInvalidState) return;

        if (mBbsShellService != null) {
            // Do not leave service and session clients with references to activity.
            mBbsShellService.unsetBbsShellTerminalSessionClient();
            mBbsShellService = null;
        }

        try {
            unbindService(this);
        } catch (Exception e) {
            // ignore.
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        saveTerminalToolbarTextInput(savedInstanceState);
    }





    /**
     * Part of the {@link ServiceConnection} interface. The service is bound with
     * {@link #bindService(Intent, ServiceConnection, int)} in {@link #onCreate(Bundle)} which will cause a call to this
     * callback method.
     */
    @Override
    public void onServiceConnected(ComponentName componentName, IBinder service) {

        Logger.logDebug(LOG_TAG, "onServiceConnected");

        mBbsShellService = ((BbsShellService.LocalBinder) service).service;

        setBbsShellSessionsListView();

        if (mBbsShellService.isBbsShellSessionsEmpty()) {
            if (mIsVisible) {
                BbsShellInstaller.setupBootstrapIfNeeded(BbsShellActivity.this, () -> {
                    if (mBbsShellService == null) return; // Activity might have been destroyed.
                    try {
                        Bundle bundle = getIntent().getExtras();
                        boolean launchFailsafe = false;
                        if (bundle != null) {
                            launchFailsafe = bundle.getBoolean(BBSSHELL_ACTIVITY.EXTRA_FAILSAFE_SESSION, false);
                        }
                        mBbsShellTerminalSessionClient.addNewSession(launchFailsafe, null);
                    } catch (WindowManager.BadTokenException e) {
                        // Activity finished - ignore.
                    }
                });
            } else {
                // The service connected while not in foreground - just bail out.
                finishActivityIfNotFinishing();
            }
        } else {
            Intent i = getIntent();
            if (i != null && Intent.ACTION_RUN.equals(i.getAction())) {
                // Android 7.1 app shortcut from res/xml/shortcuts.xml.
                boolean isFailSafe = i.getBooleanExtra(BBSSHELL_ACTIVITY.EXTRA_FAILSAFE_SESSION, false);
                mBbsShellTerminalSessionClient.addNewSession(isFailSafe, null);
            } else {
                mBbsShellTerminalSessionClient.setCurrentSession(mBbsShellTerminalSessionClient.getCurrentStoredSessionOrLast());
            }
        }

        // Update the {@link TerminalSession} and {@link TerminalEmulator} clients.
        mBbsShellService.setBbsShellTerminalSessionClient(mBbsShellTerminalSessionClient);
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {

        Logger.logDebug(LOG_TAG, "onServiceDisconnected");

        // Respect being stopped from the {@link BbsShellService} notification action.
        finishActivityIfNotFinishing();
    }





    private void setActivityTheme() {
        if (mProperties.isUsingBlackUI()) {
            this.setTheme(R.style.Theme_BbsShell_Black);
        } else {
            this.setTheme(R.style.Theme_BbsShell);
        }
    }

    private void setDrawerTheme() {
        BbsShellTheme.applyWindow(this);
        BbsShellTheme.populatePicker(this, findViewById(R.id.theme_picker_container), this::onThemeSelected);
    }

    private void onThemeSelected() {
        BbsShellTheme.applyWindow(this);
        BbsShellTheme.populatePicker(this, findViewById(R.id.theme_picker_container), this::onThemeSelected);
        if (mBbsShellTerminalSessionClient != null)
            mBbsShellTerminalSessionClient.onReload();
    }

    private void setMargins() {
        RelativeLayout relativeLayout = findViewById(R.id.activity_bbsshell_root_relative_layout);
        int marginHorizontal = mProperties.getTerminalMarginHorizontal();
        int marginVertical = mProperties.getTerminalMarginVertical();
        ViewUtils.setLayoutMarginsInDp(relativeLayout, marginHorizontal, marginVertical, marginHorizontal, marginVertical);
    }



    public void addBbsShellActivityRootViewGlobalLayoutListener() {
        getBbsShellActivityRootView().getViewTreeObserver().addOnGlobalLayoutListener(getBbsShellActivityRootView());
    }

    public void removeBbsShellActivityRootViewGlobalLayoutListener() {
        if (getBbsShellActivityRootView() != null)
            getBbsShellActivityRootView().getViewTreeObserver().removeOnGlobalLayoutListener(getBbsShellActivityRootView());
    }



    private void setBbsShellTerminalViewAndClients() {
        // Set bbsshell terminal view and session clients
        mBbsShellTerminalSessionClient = new BbsShellTerminalSessionClient(this);
        mBbsShellTerminalViewClient = new BbsShellTerminalViewClient(this, mBbsShellTerminalSessionClient);

        // Set bbsshell terminal view
        mTerminalView = findViewById(R.id.terminal_view);
        mTerminalView.setTerminalViewClient(mBbsShellTerminalViewClient);

        if (mBbsShellTerminalViewClient != null)
            mBbsShellTerminalViewClient.onCreate();

        if (mBbsShellTerminalSessionClient != null)
            mBbsShellTerminalSessionClient.onCreate();
    }

    private void setBbsShellSessionsListView() {
        ListView bbsshellSessionsListView = findViewById(R.id.terminal_sessions_list);
        mBbsShellSessionListViewController = new BbsShellSessionsListViewController(this, mBbsShellService.getBbsShellSessions());
        bbsshellSessionsListView.setAdapter(mBbsShellSessionListViewController);
        bbsshellSessionsListView.setOnItemClickListener(mBbsShellSessionListViewController);
        bbsshellSessionsListView.setOnItemLongClickListener(mBbsShellSessionListViewController);
    }



    private void setTerminalToolbarView(Bundle savedInstanceState) {
        final ViewPager terminalToolbarViewPager = getTerminalToolbarViewPager();
        if (mPreferences.shouldShowTerminalToolbar()) terminalToolbarViewPager.setVisibility(View.VISIBLE);

        ViewGroup.LayoutParams layoutParams = terminalToolbarViewPager.getLayoutParams();
        mTerminalToolbarDefaultHeight = layoutParams.height;

        setTerminalToolbarHeight();

        String savedTextInput = null;
        if (savedInstanceState != null)
            savedTextInput = savedInstanceState.getString(ARG_TERMINAL_TOOLBAR_TEXT_INPUT);

        terminalToolbarViewPager.setAdapter(new TerminalToolbarViewPager.PageAdapter(this, savedTextInput));
        terminalToolbarViewPager.addOnPageChangeListener(new TerminalToolbarViewPager.OnPageChangeListener(this, terminalToolbarViewPager));
    }

    private void setTerminalToolbarHeight() {
        final ViewPager terminalToolbarViewPager = getTerminalToolbarViewPager();
        if (terminalToolbarViewPager == null) return;

        ViewGroup.LayoutParams layoutParams = terminalToolbarViewPager.getLayoutParams();
        layoutParams.height = (int) Math.round(mTerminalToolbarDefaultHeight *
            (mProperties.getExtraKeysInfo() == null ? 0 : mProperties.getExtraKeysInfo().getMatrix().length) *
            mProperties.getTerminalToolbarHeightScaleFactor());
        terminalToolbarViewPager.setLayoutParams(layoutParams);
    }

    public void toggleTerminalToolbar() {
        final ViewPager terminalToolbarViewPager = getTerminalToolbarViewPager();
        if (terminalToolbarViewPager == null) return;

        final boolean showNow = mPreferences.toogleShowTerminalToolbar();
        Logger.showToast(this, (showNow ? getString(R.string.msg_enabling_terminal_toolbar) : getString(R.string.msg_disabling_terminal_toolbar)), true);
        terminalToolbarViewPager.setVisibility(showNow ? View.VISIBLE : View.GONE);
        if (showNow && isTerminalToolbarTextInputViewSelected()) {
            // Focus the text input view if just revealed.
            findViewById(R.id.terminal_toolbar_text_input).requestFocus();
        }
    }

    private void saveTerminalToolbarTextInput(Bundle savedInstanceState) {
        if (savedInstanceState == null) return;

        final EditText textInputView =  findViewById(R.id.terminal_toolbar_text_input);
        if (textInputView != null) {
            String textInput = textInputView.getText().toString();
            if (!textInput.isEmpty()) savedInstanceState.putString(ARG_TERMINAL_TOOLBAR_TEXT_INPUT, textInput);
        }
    }



    private void setSettingsButtonView() {
        ImageButton settingsButton = findViewById(R.id.settings_button);
        settingsButton.setOnClickListener(v -> {
            startActivity(new Intent(this, SettingsActivity.class));
        });
    }

    private void setNewSessionButtonView() {
        View newSessionButton = findViewById(R.id.new_session_button);
        newSessionButton.setOnClickListener(v -> mBbsShellTerminalSessionClient.addNewSession(false, null));
        newSessionButton.setOnLongClickListener(v -> {
            TextInputDialogUtils.textInput(BbsShellActivity.this, R.string.title_create_named_session, null,
                R.string.action_create_named_session_confirm, text -> mBbsShellTerminalSessionClient.addNewSession(false, text),
                R.string.action_new_session_failsafe, text -> mBbsShellTerminalSessionClient.addNewSession(true, text),
                -1, null, null);
            return true;
        });
    }

    private void setToggleKeyboardView() {
        findViewById(R.id.toggle_keyboard_button).setOnClickListener(v -> {
            mBbsShellTerminalViewClient.onToggleSoftKeyboardRequest();
            getDrawer().closeDrawers();
        });

        findViewById(R.id.toggle_keyboard_button).setOnLongClickListener(v -> {
            toggleTerminalToolbar();
            return true;
        });
    }





    @SuppressLint("RtlHardcoded")
    @Override
    public void onBackPressed() {
        if (getDrawer().isDrawerOpen(Gravity.LEFT)) {
            getDrawer().closeDrawers();
        } else {
            finishActivityIfNotFinishing();
        }
    }

    public void finishActivityIfNotFinishing() {
        // prevent duplicate calls to finish() if called from multiple places
        if (!BbsShellActivity.this.isFinishing()) {
            finish();
        }
    }

    /** Show a toast and dismiss the last one if still visible. */
    public void showToast(String text, boolean longDuration) {
        if (text == null || text.isEmpty()) return;
        if (mLastToast != null) mLastToast.cancel();
        mLastToast = Toast.makeText(BbsShellActivity.this, text, longDuration ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT);
        mLastToast.setGravity(Gravity.TOP, 0, 0);
        mLastToast.show();
    }



    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        TerminalSession currentSession = getCurrentSession();
        if (currentSession == null) return;

        boolean autoFillEnabled = mTerminalView.isAutoFillEnabled();

        menu.add(Menu.NONE, CONTEXT_MENU_SELECT_URL_ID, Menu.NONE, R.string.action_select_url);
        menu.add(Menu.NONE, CONTEXT_MENU_SHARE_TRANSCRIPT_ID, Menu.NONE, R.string.action_share_transcript);
        if (!DataUtils.isNullOrEmpty(mTerminalView.getStoredSelectedText()))
            menu.add(Menu.NONE, CONTEXT_MENU_SHARE_SELECTED_TEXT, Menu.NONE, R.string.action_share_selected_text);
        if (autoFillEnabled)
            menu.add(Menu.NONE, CONTEXT_MENU_AUTOFILL_USERNAME, Menu.NONE, R.string.action_autofill_username);
        if (autoFillEnabled)
            menu.add(Menu.NONE, CONTEXT_MENU_AUTOFILL_PASSWORD, Menu.NONE, R.string.action_autofill_password);
        menu.add(Menu.NONE, CONTEXT_MENU_RESET_TERMINAL_ID, Menu.NONE, R.string.action_reset_terminal);
        menu.add(Menu.NONE, CONTEXT_MENU_KILL_PROCESS_ID, Menu.NONE, getResources().getString(R.string.action_kill_process, getCurrentSession().getPid())).setEnabled(currentSession.isRunning());
        menu.add(Menu.NONE, CONTEXT_MENU_TOGGLE_KEEP_SCREEN_ON, Menu.NONE, R.string.action_toggle_keep_screen_on).setCheckable(true).setChecked(mPreferences.shouldKeepScreenOn());
        menu.add(Menu.NONE, CONTEXT_MENU_HELP_ID, Menu.NONE, R.string.action_open_help);
        menu.add(Menu.NONE, CONTEXT_MENU_SETTINGS_ID, Menu.NONE, R.string.action_open_settings);
        menu.add(Menu.NONE, CONTEXT_MENU_REPORT_ID, Menu.NONE, R.string.action_report_issue);
    }

    /** Hook system menu to show context menu instead. */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        mTerminalView.showContextMenu();
        return false;
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        TerminalSession session = getCurrentSession();

        switch (item.getItemId()) {
            case CONTEXT_MENU_SELECT_URL_ID:
                mBbsShellTerminalViewClient.showUrlSelection();
                return true;
            case CONTEXT_MENU_SHARE_TRANSCRIPT_ID:
                mBbsShellTerminalViewClient.shareSessionTranscript();
                return true;
            case CONTEXT_MENU_SHARE_SELECTED_TEXT:
                mBbsShellTerminalViewClient.shareSelectedText();
                return true;
            case CONTEXT_MENU_AUTOFILL_USERNAME:
                mTerminalView.requestAutoFillUsername();
                return true;
            case CONTEXT_MENU_AUTOFILL_PASSWORD:
                mTerminalView.requestAutoFillPassword();
                return true;
            case CONTEXT_MENU_RESET_TERMINAL_ID:
                onResetTerminalSession(session);
                return true;
            case CONTEXT_MENU_KILL_PROCESS_ID:
                showKillSessionDialog(session);
                return true;
            case CONTEXT_MENU_TOGGLE_KEEP_SCREEN_ON:
                toggleKeepScreenOn();
                return true;
            case CONTEXT_MENU_HELP_ID:
                startActivity(new Intent(this, HelpActivity.class));
                return true;
            case CONTEXT_MENU_SETTINGS_ID:
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
            case CONTEXT_MENU_REPORT_ID:
                mBbsShellTerminalViewClient.reportIssueFromTranscript();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    @Override
    public void onContextMenuClosed(Menu menu) {
        super.onContextMenuClosed(menu);
        // onContextMenuClosed() is triggered twice if back button is pressed to dismiss instead of tap for some reason
        mTerminalView.onContextMenuClosed(menu);
    }

    private void showKillSessionDialog(TerminalSession session) {
        if (session == null) return;

        final AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setIcon(android.R.drawable.ic_dialog_alert);
        b.setMessage(R.string.title_confirm_kill_process);
        b.setPositiveButton(android.R.string.yes, (dialog, id) -> {
            dialog.dismiss();
            session.finishIfRunning();
        });
        b.setNegativeButton(android.R.string.no, null);
        b.show();
    }

    private void onResetTerminalSession(TerminalSession session) {
        if (session != null) {
            session.reset();
            showToast(getResources().getString(R.string.msg_terminal_reset), true);

            if (mBbsShellTerminalSessionClient != null)
                mBbsShellTerminalSessionClient.onResetTerminalSession();
        }
    }

    private void toggleKeepScreenOn() {
        if (mTerminalView.getKeepScreenOn()) {
            mTerminalView.setKeepScreenOn(false);
            mPreferences.setKeepScreenOn(false);
        } else {
            mTerminalView.setKeepScreenOn(true);
            mPreferences.setKeepScreenOn(true);
        }
    }



    /**
     * For processes to access shared internal storage (/sdcard) we need this permission.
     */
    public boolean ensureStoragePermissionGranted() {
        if (PermissionUtils.checkPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            return true;
        } else {
            Logger.logInfo(LOG_TAG, "Storage permission not granted, requesting permission.");
            PermissionUtils.requestPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE, PermissionUtils.REQUEST_GRANT_STORAGE_PERMISSION);
            return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PermissionUtils.REQUEST_GRANT_STORAGE_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Logger.logInfo(LOG_TAG, "Storage permission granted by user on request.");
            BbsShellInstaller.setupStorageSymlinks(this);
        } else {
            Logger.logInfo(LOG_TAG, "Storage permission denied by user on request.");
        }
    }



    public int getNavBarHeight() {
        return mNavBarHeight;
    }

    public BbsShellActivityRootView getBbsShellActivityRootView() {
        return mBbsShellActivityRootView;
    }

    public View getBbsShellActivityBottomSpaceView() {
        return mBbsShellActivityBottomSpaceView;
    }

    public ExtraKeysView getExtraKeysView() {
        return mExtraKeysView;
    }

    public void setExtraKeysView(ExtraKeysView extraKeysView) {
        mExtraKeysView = extraKeysView;
    }

    public DrawerLayout getDrawer() {
        return (DrawerLayout) findViewById(R.id.drawer_layout);
    }


    public ViewPager getTerminalToolbarViewPager() {
        return (ViewPager) findViewById(R.id.terminal_toolbar_view_pager);
    }

    public boolean isTerminalViewSelected() {
        return getTerminalToolbarViewPager().getCurrentItem() == 0;
    }

    public boolean isTerminalToolbarTextInputViewSelected() {
        return getTerminalToolbarViewPager().getCurrentItem() == 1;
    }


    public void bbsshellSessionListNotifyUpdated() {
        mBbsShellSessionListViewController.notifyDataSetChanged();
    }

    public boolean isVisible() {
        return mIsVisible;
    }

    public boolean isOnResumeAfterOnCreate() {
        return isOnResumeAfterOnCreate;
    }



    public BbsShellService getBbsShellService() {
        return mBbsShellService;
    }

    public TerminalView getTerminalView() {
        return mTerminalView;
    }

    public BbsShellTerminalViewClient getBbsShellTerminalViewClient() {
        return mBbsShellTerminalViewClient;
    }

    public BbsShellTerminalSessionClient getBbsShellTerminalSessionClient() {
        return mBbsShellTerminalSessionClient;
    }

    @Nullable
    public TerminalSession getCurrentSession() {
        if (mTerminalView != null)
            return mTerminalView.getCurrentSession();
        else
            return null;
    }

    public BbsShellAppSharedPreferences getPreferences() {
        return mPreferences;
    }

    public BbsShellAppSharedProperties getProperties() {
        return mProperties;
    }




    public static void updateBbsShellActivityStyling(Context context) {
        // Make sure that terminal styling is always applied.
        Intent stylingIntent = new Intent(BBSSHELL_ACTIVITY.ACTION_RELOAD_STYLE);
        context.sendBroadcast(stylingIntent);
    }

    private void registerBbsShellActivityBroadcastReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BBSSHELL_ACTIVITY.ACTION_REQUEST_PERMISSIONS);
        intentFilter.addAction(BBSSHELL_ACTIVITY.ACTION_RELOAD_STYLE);

        registerReceiver(mBbsShellActivityBroadcastReceiver, intentFilter);
    }

    private void unregisterBbsShellActivityBroadcastReceiever() {
        unregisterReceiver(mBbsShellActivityBroadcastReceiver);
    }

    private void fixBbsShellActivityBroadcastReceieverIntent(Intent intent) {
        if (intent == null) return;

        String extraReloadStyle = intent.getStringExtra(BBSSHELL_ACTIVITY.EXTRA_RELOAD_STYLE);
        if ("storage".equals(extraReloadStyle)) {
            intent.removeExtra(BBSSHELL_ACTIVITY.EXTRA_RELOAD_STYLE);
            intent.setAction(BBSSHELL_ACTIVITY.ACTION_REQUEST_PERMISSIONS);
        }
    }

    class BbsShellActivityBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;

            if (mIsVisible) {
                fixBbsShellActivityBroadcastReceieverIntent(intent);

                switch (intent.getAction()) {
                    case BBSSHELL_ACTIVITY.ACTION_REQUEST_PERMISSIONS:
                        Logger.logDebug(LOG_TAG, "Received intent to request storage permissions");
                        if (ensureStoragePermissionGranted())
                            BbsShellInstaller.setupStorageSymlinks(BbsShellActivity.this);
                        return;
                    case BBSSHELL_ACTIVITY.ACTION_RELOAD_STYLE:
                        Logger.logDebug(LOG_TAG, "Received intent to reload styling");
                        reloadActivityStyling();
                        return;
                    default:
                }
            }
        }
    }

    private void reloadActivityStyling() {
        if (mProperties!= null) {
            mProperties.loadBbsShellPropertiesFromDisk();

            if (mExtraKeysView != null) {
                mExtraKeysView.setButtonTextAllCaps(mProperties.shouldExtraKeysTextBeAllCaps());
                mExtraKeysView.reload(mProperties.getExtraKeysInfo());
            }
        }

        setMargins();
        setTerminalToolbarHeight();

        if (mBbsShellTerminalSessionClient != null)
            mBbsShellTerminalSessionClient.onReload();

        if (mBbsShellTerminalViewClient != null)
            mBbsShellTerminalViewClient.onReload();

        if (mBbsShellService != null)
            mBbsShellService.setTerminalTranscriptRows();

        // To change the activity and drawer theme, activity needs to be recreated.
        // But this will destroy the activity, and will call the onCreate() again.
        // We need to investigate if enabling this is wise, since all stored variables and
        // views will be destroyed and bindService() will be called again. Extra keys input
        // text will we restored since that has already been implemented. Terminal sessions
        // and transcripts are also already preserved. Theme does change properly too.
        // BbsShellActivity.this.recreate();
    }



    public static void startBbsShellActivity(@NonNull final Context context) {
        context.startActivity(newInstance(context));
    }

    public static Intent newInstance(@NonNull final Context context) {
        Intent intent = new Intent(context, BbsShellActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return intent;
    }

}
