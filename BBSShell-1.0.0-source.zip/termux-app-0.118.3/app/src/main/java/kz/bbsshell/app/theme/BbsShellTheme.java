package kz.bbsshell.app.theme;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Properties;

import kz.bbsshell.app.R;

/**
 * Built-in visual themes. A theme defines the terminal palette and the glass-style UI colors.
 * The selected theme is stored in a private preference file.
 */
public final class BbsShellTheme {

    private static final String PREFS_NAME = "bbsshell_ui";
    private static final String KEY_THEME_INDEX = "theme_index";

    /** ANSI colors 0..15 shared by all themes (all themes are dark, so the text stays readable). */
    private static final String[] ANSI_DARK = {
        "#1E293B", "#F87171", "#4ADE80", "#FACC15", "#60A5FA", "#C084FC", "#22D3EE", "#CBD5E1",
        "#475569", "#FCA5A5", "#86EFAC", "#FDE68A", "#93C5FD", "#D8B4FE", "#67E8F9", "#F8FAFC"
    };

    public static final BbsShellTheme[] THEMES = {
        new BbsShellTheme("Cyan Glass", "#0B1220", "#E2E8F0", "#22D3EE"),
        new BbsShellTheme("Midnight", "#090B10", "#D4D4D8", "#60A5FA"),
        new BbsShellTheme("Graphite", "#16171B", "#E4E4E7", "#A1A1AA"),
        new BbsShellTheme("Nord", "#2E3440", "#ECEFF4", "#88C0D0"),
        new BbsShellTheme("Forest", "#0E1812", "#DCEBDD", "#4ADE80"),
        new BbsShellTheme("Teal Lagoon", "#0A1A1F", "#D6EAF0", "#2DD4BF"),
        new BbsShellTheme("Violet Haze", "#14101E", "#E9E3F5", "#A78BFA"),
        new BbsShellTheme("Rose Dusk", "#1E1116", "#F5E1E6", "#FB7185"),
        new BbsShellTheme("Amber Night", "#1A150C", "#F3E9D2", "#FBBF24"),
        new BbsShellTheme("Solarized", "#002B36", "#93A1A1", "#2AA198"),
        new BbsShellTheme("Slate", "#1C2230", "#E5E7EB", "#38BDF8"),
        new BbsShellTheme("Mocha", "#1E1A17", "#EDE3D8", "#D6A77A"),
    };

    private final String name;
    private final int background;
    private final int foreground;
    private final int accent;

    private BbsShellTheme(String name, String background, String foreground, String accent) {
        this.name = name;
        this.background = Color.parseColor(background);
        this.foreground = Color.parseColor(foreground);
        this.accent = Color.parseColor(accent);
    }

    public String getName() {
        return name;
    }

    /** Terminal colors in colors.properties format, understood by TerminalColorScheme.updateWith(). */
    public Properties toTerminalProperties() {
        Properties props = new Properties();
        for (int i = 0; i < ANSI_DARK.length; i++)
            props.setProperty("color" + i, ANSI_DARK[i]);
        props.setProperty("foreground", hex(foreground));
        props.setProperty("background", hex(background));
        props.setProperty("cursor", hex(accent));
        return props;
    }

    public static int getSelectedIndex(Context context) {
        int index = prefs(context).getInt(KEY_THEME_INDEX, 0);
        return (index >= 0 && index < THEMES.length) ? index : 0;
    }

    public static BbsShellTheme getSelected(Context context) {
        return THEMES[getSelectedIndex(context)];
    }

    public static void setSelectedIndex(Context context, int index) {
        prefs(context).edit().putInt(KEY_THEME_INDEX, index).apply();
    }

    /** Applies the selected theme to the activity chrome: window, glass drawer, bottom bar and theme label. */
    public static void applyWindow(Activity activity) {
        BbsShellTheme theme = getSelected(activity);
        float density = activity.getResources().getDisplayMetrics().density;

        activity.getWindow().setStatusBarColor(theme.background);
        activity.getWindow().setNavigationBarColor(theme.background);
        activity.getWindow().getDecorView().setBackgroundColor(theme.background);

        View root = activity.findViewById(R.id.activity_bbsshell_root_view);
        if (root != null) root.setBackgroundColor(theme.background);

        View drawer = activity.findViewById(R.id.left_drawer);
        if (drawer != null) drawer.setBackground(theme.createGlassDrawable(24 * density, density));

        ImageButton settings = activity.findViewById(R.id.settings_button);
        if (settings != null) settings.setColorFilter(theme.foreground);

        View toolbar = activity.findViewById(R.id.terminal_toolbar_view_pager);
        if (toolbar != null) toolbar.setBackgroundColor(withAlpha(theme.background, 0xCC));

        TextView label = activity.findViewById(R.id.theme_picker_label);
        if (label != null) {
            label.setText(activity.getString(R.string.theme_picker_title, theme.name));
            label.setTextColor(theme.accent);
        }
    }

    /** Fills the horizontal row of theme swatches. Tapping a swatch selects that theme. */
    public static void populatePicker(Activity activity, LinearLayout container, Runnable onSelected) {
        if (container == null) return;
        container.removeAllViews();
        float density = activity.getResources().getDisplayMetrics().density;
        int selected = getSelectedIndex(activity);

        for (int i = 0; i < THEMES.length; i++) {
            final int index = i;
            BbsShellTheme theme = THEMES[i];

            GradientDrawable swatch = new GradientDrawable();
            swatch.setShape(GradientDrawable.OVAL);
            swatch.setColor(i == selected ? theme.accent : theme.background);
            swatch.setStroke((int) (3 * density), theme.accent);

            View view = new View(activity);
            view.setBackground(swatch);
            view.setContentDescription(theme.name);
            int size = (int) (34 * density);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.setMargins((int) (4 * density), 0, (int) (10 * density), 0);
            view.setLayoutParams(params);
            view.setOnClickListener(v -> {
                setSelectedIndex(activity, index);
                onSelected.run();
            });
            container.addView(view);
        }
    }

    /** Glass surface: a translucent tinted panel with a faint light border and rounded right corners. */
    private GradientDrawable createGlassDrawable(float radiusPx, float density) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(withAlpha(background, 0xD9));
        drawable.setStroke(Math.max(1, (int) density), withAlpha(foreground, 0x2E));
        drawable.setCornerRadii(new float[]{0, 0, radiusPx, radiusPx, radiusPx, radiusPx, 0, 0});
        return drawable;
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0xFFFFFF) | (alpha << 24);
    }

    private static String hex(int color) {
        return String.format("#%06X", color & 0xFFFFFF);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
}
