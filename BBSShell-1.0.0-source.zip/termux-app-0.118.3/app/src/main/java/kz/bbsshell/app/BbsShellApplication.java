package kz.bbsshell.app;

import android.app.Application;

import kz.bbsshell.shared.crash.BbsShellCrashUtils;
import kz.bbsshell.shared.settings.preferences.BbsShellAppSharedPreferences;
import kz.bbsshell.shared.logger.Logger;


public class BbsShellApplication extends Application {
    public void onCreate() {
        super.onCreate();

        // Set crash handler for the app
        BbsShellCrashUtils.setCrashHandler(this);

        // Set log level for the app
        setLogLevel();
    }

    private void setLogLevel() {
        // Load the log level from shared preferences and set it to the {@link Logger.CURRENT_LOG_LEVEL}
        BbsShellAppSharedPreferences preferences = BbsShellAppSharedPreferences.build(getApplicationContext());
        if (preferences == null) return;
        preferences.setLogLevel(null, preferences.getLogLevel());
        Logger.logDebug("Starting Application");
    }
}

