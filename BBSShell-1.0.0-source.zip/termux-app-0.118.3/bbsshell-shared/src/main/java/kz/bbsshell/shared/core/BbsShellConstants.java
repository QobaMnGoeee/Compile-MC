package kz.bbsshell.shared.core;

import android.annotation.SuppressLint;

import kz.bbsshell.shared.models.ResultConfig;
import kz.bbsshell.shared.models.errors.Errno;

import java.io.File;
import java.util.Arrays;
import java.util.Formatter;
import java.util.IllegalFormatException;
import java.util.List;

/*
 * Version: v0.32.0
 *
 * Changelog
 *
 * - 0.1.0 (2021-03-08)
 *      - Initial Release.
 *
 * - 0.2.0 (2021-03-11)
 *      - Added `_DIR` and `_FILE` substrings to paths.
 *      - Added `INTERNAL_PRIVATE_APP_DATA_DIR*`, `BBSSHELL_CACHE_DIR*`, `BBSSHELL_DATABASES_DIR*`,
 *          `BBSSHELL_SHARED_PREFERENCES_DIR*`, `BBSSHELL_BIN_PREFIX_DIR*`, `BBSSHELL_ETC_DIR*`,
 *          `BBSSHELL_INCLUDE_DIR*`, `BBSSHELL_LIB_DIR*`, `BBSSHELL_LIBEXEC_DIR*`, `BBSSHELL_SHARE_DIR*`,
 *          `BBSSHELL_TMP_DIR*`, `BBSSHELL_VAR_DIR*`, `BBSSHELL_STAGING_PREFIX_DIR*`,
 *          `BBSSHELL_STORAGE_HOME_DIR*`, `BBSSHELL_DEFAULT_PREFERENCES_FILE_BASENAME*`,
 *          `BBSSHELL_DEFAULT_PREFERENCES_FILE`.
 *      - Renamed `DATA_HOME_PATH` to `BBSSHELL_DATA_HOME_DIR_PATH`.
 *      - Renamed `CONFIG_HOME_PATH` to `BBSSHELL_CONFIG_HOME_DIR_PATH`.
 *      - Updated javadocs and spacing.
 *
 * - 0.3.0 (2021-03-12)
 *      - Remove `BBSSHELL_CACHE_DIR_PATH*`, `BBSSHELL_DATABASES_DIR_PATH*`,
 *          `BBSSHELL_SHARED_PREFERENCES_DIR_PATH*` since they may not be consistent on all devices.
 *      - Renamed `BBSSHELL_DEFAULT_PREFERENCES_FILE_BASENAME` to
 *          `BBSSHELL_DEFAULT_PREFERENCES_FILE_BASENAME_WITHOUT_EXTENSION`. This should be used for
 *           accessing shared preferences between BBS Shell app and its plugins if ever needed by first
 *           getting shared package context with {@link Context.createPackageContext(String,int}).
 *
 * - 0.4.0 (2021-03-16)
 *      - Added `BROADCAST_BBSSHELL_OPENED`,
 *          `BBSSHELL_API_DEFAULT_PREFERENCES_FILE_BASENAME_WITHOUT_EXTENSION`
 *          `BBSSHELL_BOOT_DEFAULT_PREFERENCES_FILE_BASENAME_WITHOUT_EXTENSION`,
 *          `BBSSHELL_FLOAT_DEFAULT_PREFERENCES_FILE_BASENAME_WITHOUT_EXTENSION`,
 *          `BBSSHELL_STYLING_DEFAULT_PREFERENCES_FILE_BASENAME_WITHOUT_EXTENSION`,
 *          `BBSSHELL_TASKER_DEFAULT_PREFERENCES_FILE_BASENAME_WITHOUT_EXTENSION`,
 *          `BBSSHELL_WIDGET_DEFAULT_PREFERENCES_FILE_BASENAME_WITHOUT_EXTENSION`.
 *
 * - 0.5.0 (2021-03-16)
 *      - Renamed "BBS Shell Plugin app" labels to "BBS Shell:Tasker app".
 *
 * - 0.6.0 (2021-03-16)
 *      - Added `BBSSHELL_FILE_SHARE_URI_AUTHORITY`.
 *
 * - 0.7.0 (2021-03-17)
 *      - Fixed javadocs.
 *
 * - 0.8.0 (2021-03-18)
 *      - Fixed Intent extra types javadocs.
 *      - Added following to `BBSSHELL_SERVICE`:
 *          `EXTRA_PENDING_INTENT`, `EXTRA_RESULT_BUNDLE`,
 *          `EXTRA_STDOUT`, `EXTRA_STDERR`, `EXTRA_EXIT_CODE`,
 *          `EXTRA_ERR`, `EXTRA_ERRMSG`.
 *
 * - 0.9.0 (2021-03-18)
 *      - Fixed javadocs.
 *
 * - 0.10.0 (2021-03-19)
 *      - Added following to `BBSSHELL_SERVICE`:
 *          `EXTRA_SESSION_ACTION`,
 *          `VALUE_EXTRA_SESSION_ACTION_SWITCH_TO_NEW_SESSION_AND_OPEN_ACTIVITY`,
 *          `VALUE_EXTRA_SESSION_ACTION_KEEP_CURRENT_SESSION_AND_OPEN_ACTIVITY`,
 *          `VALUE_EXTRA_SESSION_ACTION_SWITCH_TO_NEW_SESSION_AND_DONT_OPEN_ACTIVITY`
 *          `VALUE_EXTRA_SESSION_ACTION_KEEP_CURRENT_SESSION_AND_DONT_OPEN_ACTIVITY`.
 *      - Added following to `RUN_COMMAND_SERVICE`:
 *          `EXTRA_SESSION_ACTION`.
 *
 * - 0.11.0 (2021-03-24)
 *      - Added following to `BBSSHELL_SERVICE`:
 *          `EXTRA_COMMAND_LABEL`, `EXTRA_COMMAND_DESCRIPTION`, `EXTRA_COMMAND_HELP`, `EXTRA_PLUGIN_API_HELP`.
 *      - Added following to `RUN_COMMAND_SERVICE`:
 *          `EXTRA_COMMAND_LABEL`, `EXTRA_COMMAND_DESCRIPTION`, `EXTRA_COMMAND_HELP`.
 *      - Updated `RESULT_BUNDLE` related extras with `PLUGIN_RESULT_BUNDLE` prefixes.
 *
 * - 0.12.0 (2021-03-25)
 *      - Added following to `BBSSHELL_SERVICE`:
 *          `EXTRA_PLUGIN_RESULT_BUNDLE_STDOUT_ORIGINAL_LENGTH`,
 *          `EXTRA_PLUGIN_RESULT_BUNDLE_STDERR_ORIGINAL_LENGTH`.
 *
 * - 0.13.0 (2021-03-25)
 *      - Added following to `RUN_COMMAND_SERVICE`:
 *          `EXTRA_PENDING_INTENT`.
 *
 * - 0.14.0 (2021-03-25)
 *      - Added `FDROID_PACKAGES_BASE_URL`,
 *          `BBSSHELL_GITHUB_ORGANIZATION_NAME`, `BBSSHELL_GITHUB_ORGANIZATION_URL`,
 *          `BBSSHELL_GITHUB_REPO_NAME`, `BBSSHELL_GITHUB_REPO_URL`, `BBSSHELL_FDROID_PACKAGE_URL`,
 *          `BBSSHELL_API_GITHUB_REPO_NAME`,`BBSSHELL_API_GITHUB_REPO_URL`, `BBSSHELL_API_FDROID_PACKAGE_URL`,
 *          `BBSSHELL_BOOT_GITHUB_REPO_NAME`, `BBSSHELL_BOOT_GITHUB_REPO_URL`, `BBSSHELL_BOOT_FDROID_PACKAGE_URL`,
 *          `BBSSHELL_FLOAT_GITHUB_REPO_NAME`, `BBSSHELL_FLOAT_GITHUB_REPO_URL`, `BBSSHELL_FLOAT_FDROID_PACKAGE_URL`,
 *          `BBSSHELL_STYLING_GITHUB_REPO_NAME`, `BBSSHELL_STYLING_GITHUB_REPO_URL`, `BBSSHELL_STYLING_FDROID_PACKAGE_URL`,
 *          `BBSSHELL_TASKER_GITHUB_REPO_NAME`, `BBSSHELL_TASKER_GITHUB_REPO_URL`, `BBSSHELL_TASKER_FDROID_PACKAGE_URL`,
 *          `BBSSHELL_WIDGET_GITHUB_REPO_NAME`, `BBSSHELL_WIDGET_GITHUB_REPO_URL` `BBSSHELL_WIDGET_FDROID_PACKAGE_URL`.
 *
 * - 0.15.0 (2021-04-06)
 *      - Fixed some variables that had `PREFIX_` substring missing in their name.
 *      - Added `BBSSHELL_CRASH_LOG_FILE_PATH`, `BBSSHELL_CRASH_LOG_BACKUP_FILE_PATH`,
 *          `BBSSHELL_GITHUB_ISSUES_REPO_URL`, `BBSSHELL_API_GITHUB_ISSUES_REPO_URL`,
 *          `BBSSHELL_BOOT_GITHUB_ISSUES_REPO_URL`, `BBSSHELL_FLOAT_GITHUB_ISSUES_REPO_URL`,
 *          `BBSSHELL_STYLING_GITHUB_ISSUES_REPO_URL`, `BBSSHELL_TASKER_GITHUB_ISSUES_REPO_URL`,
 *          `BBSSHELL_WIDGET_GITHUB_ISSUES_REPO_URL`,
 *          `BBSSHELL_GITHUB_WIKI_REPO_URL`, `BBSSHELL_PACKAGES_GITHUB_WIKI_REPO_URL`,
 *          `BBSSHELL_PACKAGES_GITHUB_REPO_NAME`, `BBSSHELL_PACKAGES_GITHUB_REPO_URL`, `BBSSHELL_PACKAGES_GITHUB_ISSUES_REPO_URL`,
 *          `BBSSHELL_GAME_PACKAGES_GITHUB_REPO_NAME`, `BBSSHELL_GAME_PACKAGES_GITHUB_REPO_URL`, `BBSSHELL_GAME_PACKAGES_GITHUB_ISSUES_REPO_URL`,
 *          `BBSSHELL_SCIENCE_PACKAGES_GITHUB_REPO_NAME`, `BBSSHELL_SCIENCE_PACKAGES_GITHUB_REPO_URL`, `BBSSHELL_SCIENCE_PACKAGES_GITHUB_ISSUES_REPO_URL`,
 *          `BBSSHELL_ROOT_PACKAGES_GITHUB_REPO_NAME`, `BBSSHELL_ROOT_PACKAGES_GITHUB_REPO_URL`, `BBSSHELL_ROOT_PACKAGES_GITHUB_ISSUES_REPO_URL`,
 *          `BBSSHELL_UNSTABLE_PACKAGES_GITHUB_REPO_NAME`, `BBSSHELL_UNSTABLE_PACKAGES_GITHUB_REPO_URL`, `BBSSHELL_UNSTABLE_PACKAGES_GITHUB_ISSUES_REPO_URL`,
 *          `BBSSHELL_X11_PACKAGES_GITHUB_REPO_NAME`, `BBSSHELL_X11_PACKAGES_GITHUB_REPO_URL`, `BBSSHELL_X11_PACKAGES_GITHUB_ISSUES_REPO_URL`.
 *      - Added following to `RUN_COMMAND_SERVICE`:
 *          `RUN_COMMAND_API_HELP_URL`.
 *
 * - 0.16.0 (2021-04-06)
 *      - Added `BBSSHELL_SUPPORT_EMAIL`, `BBSSHELL_SUPPORT_EMAIL_URL`, `BBSSHELL_SUPPORT_EMAIL_MAILTO_URL`,
 *          `BBSSHELL_REDDIT_SUBREDDIT`, `BBSSHELL_REDDIT_SUBREDDIT_URL`.
 *      - The `BBSSHELL_SUPPORT_EMAIL_URL` value must be fixed later when email has been set up.
 *
 * - 0.17.0 (2021-04-07)
 *      - Added `BBSSHELL_APP_NOTIFICATION_CHANNEL_ID`, `BBSSHELL_APP_NOTIFICATION_CHANNEL_NAME`, `BBSSHELL_APP_NOTIFICATION_ID`,
 *          `BBSSHELL_RUN_COMMAND_NOTIFICATION_CHANNEL_ID`, `BBSSHELL_RUN_COMMAND_NOTIFICATION_CHANNEL_NAME`, `BBSSHELL_RUN_COMMAND_NOTIFICATION_ID`,
 *          `BBSSHELL_PLUGIN_COMMAND_ERRORS_NOTIFICATION_CHANNEL_ID`, `BBSSHELL_PLUGIN_COMMAND_ERRORS_NOTIFICATION_CHANNEL_NAME`,
 *          `BBSSHELL_CRASH_REPORTS_NOTIFICATION_CHANNEL_ID`, `BBSSHELL_CRASH_REPORTS_NOTIFICATION_CHANNEL_NAME`.
 *      - Updated javadocs.
 *
 * - 0.18.0 (2021-04-11)
 *      - Updated `BBSSHELL_SUPPORT_EMAIL_URL` to a valid email.
 *      - Removed `BBSSHELL_SUPPORT_EMAIL`.
 *
 * - 0.19.0 (2021-04-12)
 *      - Added `BBSSHELL_ACTIVITY.ACTION_REQUEST_PERMISSIONS`.
 *      - Added `BBSSHELL_SERVICE.EXTRA_STDIN`.
 *      - Added `RUN_COMMAND_SERVICE.EXTRA_STDIN`.
 *      - Deprecated `BBSSHELL_ACTIVITY.EXTRA_RELOAD_STYLE`.
 *
 * - 0.20.0 (2021-05-13)
 *      - Added `BBSSHELL_WIKI`, `BBSSHELL_WIKI_URL`, `BBSSHELL_PLUGIN_APP_NAMES_LIST`, `BBSSHELL_PLUGIN_APP_PACKAGE_NAMES_LIST`.
 *      - Added `BBSSHELL_SETTINGS_ACTIVITY_NAME`.
 *
 * - 0.21.0 (2021-05-13)
 *      - Added `APK_RELEASE_FDROID`, `APK_RELEASE_FDROID_SIGNING_CERTIFICATE_SHA256_DIGEST`,
 *          `APK_RELEASE_GITHUB_DEBUG_BUILD`, `APK_RELEASE_GITHUB_DEBUG_BUILD_SIGNING_CERTIFICATE_SHA256_DIGEST`,
 *          `APK_RELEASE_GOOGLE_PLAYSTORE`, `APK_RELEASE_GOOGLE_PLAYSTORE_SIGNING_CERTIFICATE_SHA256_DIGEST`.
 *
 * - 0.22.0 (2021-05-13)
 *      - Added `BBSSHELL_DONATE_URL`.
 *
 * - 0.23.0 (2021-06-12)
 *      - Rename `INTERNAL_PRIVATE_APP_DATA_DIR_PATH` to `BBSSHELL_INTERNAL_PRIVATE_APP_DATA_DIR_PATH`.
 *
 * - 0.24.0 (2021-06-27)
 *      - Add `COMMA_NORMAL`, `COMMA_ALTERNATIVE`.
 *      - Added following to `BBSSHELL_APP.BBSSHELL_SERVICE`:
 *          `EXTRA_RESULT_DIRECTORY`, `EXTRA_RESULT_SINGLE_FILE`, `EXTRA_RESULT_FILE_BASENAME`,
 *          `EXTRA_RESULT_FILE_OUTPUT_FORMAT`, `EXTRA_RESULT_FILE_ERROR_FORMAT`, `EXTRA_RESULT_FILES_SUFFIX`.
 *      - Added following to `BBSSHELL_APP.RUN_COMMAND_SERVICE`:
 *          `EXTRA_RESULT_DIRECTORY`, `EXTRA_RESULT_SINGLE_FILE`, `EXTRA_RESULT_FILE_BASENAME`,
 *          `EXTRA_RESULT_FILE_OUTPUT_FORMAT`, `EXTRA_RESULT_FILE_ERROR_FORMAT`, `EXTRA_RESULT_FILES_SUFFIX`,
 *          `EXTRA_REPLACE_COMMA_ALTERNATIVE_CHARS_IN_ARGUMENTS`, `EXTRA_COMMA_ALTERNATIVE_CHARS_IN_ARGUMENTS`.
 *      - Added following to `RESULT_SENDER`:
 *           `FORMAT_SUCCESS_STDOUT`, `FORMAT_SUCCESS_STDOUT__EXIT_CODE`, `FORMAT_SUCCESS_STDOUT__STDERR__EXIT_CODE`
 *           `FORMAT_FAILED_ERR__ERRMSG__STDOUT__STDERR__EXIT_CODE`,
 *           `RESULT_FILE_ERR_PREFIX`, `RESULT_FILE_ERRMSG_PREFIX` `RESULT_FILE_STDOUT_PREFIX`,
 *           `RESULT_FILE_STDERR_PREFIX`, `RESULT_FILE_EXIT_CODE_PREFIX`.
 *
 * - 0.25.0 (2021-08-19)
 *      - Added following to `BBSSHELL_APP.BBSSHELL_SERVICE`:
 *          `EXTRA_BACKGROUND_CUSTOM_LOG_LEVEL`.
 *      - Added following to `BBSSHELL_APP.RUN_COMMAND_SERVICE`:
 *          `EXTRA_BACKGROUND_CUSTOM_LOG_LEVEL`.
 *
 * - 0.26.0 (2021-08-25)
 *      - Changed `BBSSHELL_ACTIVITY.ACTION_FAILSAFE_SESSION` to `BBSSHELL_ACTIVITY.EXTRA_FAILSAFE_SESSION`.
 *
 * - 0.27.0 (2021-09-02)
 *      - Added `BBSSHELL_FLOAT_APP_NOTIFICATION_CHANNEL_ID`, `BBSSHELL_FLOAT_APP_NOTIFICATION_CHANNEL_NAME`,
 *          `BBSSHELL_FLOAT_APP.BBSSHELL_FLOAT_SERVICE_NAME`.
 *      - Added following to `BBSSHELL_FLOAT_APP.BBSSHELL_FLOAT_SERVICE`:
 *          `ACTION_STOP_SERVICE`, `ACTION_SHOW`, `ACTION_HIDE`.
 *
 * - 0.28.0 (2021-09-02)
 *      - Added `BBSSHELL_FLOAT_PROPERTIES_PRIMARY_FILE*` and `BBSSHELL_FLOAT_PROPERTIES_SECONDARY_FILE*`.
 *
 * - 0.29.0 (2021-09-04)
 *      - Added `BBSSHELL_SHORTCUT_TASKS_SCRIPTS_DIR_BASENAME`, `BBSSHELL_SHORTCUT_SCRIPT_ICONS_DIR_BASENAME`,
 *          `BBSSHELL_SHORTCUT_SCRIPT_ICONS_DIR_PATH`, `BBSSHELL_SHORTCUT_SCRIPT_ICONS_DIR`.
 *      - Added following to `BBSSHELL_WIDGET.BBSSHELL_WIDGET_PROVIDER`:
 *          `ACTION_WIDGET_ITEM_CLICKED`, `ACTION_REFRESH_WIDGET`, `EXTRA_FILE_CLICKED`.
 *      - Changed naming convention of `BBSSHELL_FLOAT_APP.BBSSHELL_FLOAT_SERVICE.ACTION_*`.
 *      - Fixed wrong path set for `BBSSHELL_SHORTCUT_SCRIPTS_DIR_PATH`.
 *
 * - 0.30.0 (2021-09-08)
 *      - Changed `APK_RELEASE_GITHUB_DEBUG_BUILD`to `APK_RELEASE_GITHUB` and
 *          `APK_RELEASE_GITHUB_DEBUG_BUILD_SIGNING_CERTIFICATE_SHA256_DIGEST` to
 *          `APK_RELEASE_GITHUB_SIGNING_CERTIFICATE_SHA256_DIGEST`.
 *
 * - 0.31.0 (2021-09-09)
 *      - Added following to `BBSSHELL_APP.BBSSHELL_SERVICE`:
 *          `MIN_VALUE_EXTRA_SESSION_ACTION` and `MAX_VALUE_EXTRA_SESSION_ACTION`.
 *
 * - 0.32.0 (2021-09-23)
 *      - Added `BBSSHELL_API.BBSSHELL_API_ACTIVITY_NAME`, `BBSSHELL_TASKER.BBSSHELL_TASKER_ACTIVITY_NAME`
 *          and `BBSSHELL_WIDGET.BBSSHELL_WIDGET_ACTIVITY_NAME`.
 */

/**
 * A class that defines shared constants of the BBS Shell app and its plugins.
 * This class will be hosted by bbsshell-shared lib and should be imported by other bbsshell plugin
 * apps as is instead of copying constants to random classes. The 3rd party apps can also import
 * it for interacting with bbsshell apps. If changes are made to this file, increment the version number
 * and add an entry in the Changelog section above.
 *
 * BBS Shell app default package name is "kz.bbsshell.app" and is used in {@link #BBSSHELL_PREFIX_DIR_PATH}.
 * The binaries compiled for bbsshell have {@link #BBSSHELL_PREFIX_DIR_PATH} hardcoded in them but it
 * can be changed during compilation.
 *
 * The {@link #BBSSHELL_PACKAGE_NAME} must be the same as the applicationId of bbsshell-app build.gradle
 * since its also used by {@link #BBSSHELL_FILES_DIR_PATH}.
 * If {@link #BBSSHELL_PACKAGE_NAME} is changed, then binaries, specially used in bootstrap need to be
 * compiled appropriately. Check https://github.com/bbsshell/bbsshell-packages/wiki/Building-packages
 * for more info.
 *
 * Ideally the only places where changes should be required if changing package name are the following:
 * - The {@link #BBSSHELL_PACKAGE_NAME} in {@link BbsShellConstants}.
 * - The "applicationId" in "build.gradle" of bbsshell-app. This is package name that android and app
 *      stores will use and is also the final package name stored in "AndroidManifest.xml".
 * - The "manifestPlaceholders" values for {@link #BBSSHELL_PACKAGE_NAME} and *_APP_NAME in
 *      "build.gradle" of bbsshell-app.
 * - The "ENTITY" values for {@link #BBSSHELL_PACKAGE_NAME} and *_APP_NAME in "strings.xml" of
 *      bbsshell-app and of bbsshell-shared.
 * - The "shortcut.xml" and "*_preferences.xml" files of bbsshell-app since dynamic variables don't
 *      work in it.
 * - Optionally the "package" in "AndroidManifest.xml" if modifying project structure of bbsshell-app.
 *      This is package name for java classes project structure and is prefixed if activity and service
 *      names use dot (.) notation. This is currently not advisable since this will break lot of
 *      stuff, including bbsshell-* packages.
 * - Optionally the *_PATH variables in {@link BbsShellConstants} containing the string "bbsshell".
 *
 * Check https://developer.android.com/studio/build/application-id for info on "package" in
 * "AndroidManifest.xml" and "applicationId" in "build.gradle".
 *
 * The {@link #BBSSHELL_PACKAGE_NAME} must be used in source code of BBS Shell app and its plugins instead
 * of hardcoded "kz.bbsshell.app" paths.
 */
public final class BbsShellConstants {


    /*
     * BBS Shell organization variables.
     */

    /** BBS Shell Github organization name */
    public static final String BBSSHELL_GITHUB_ORGANIZATION_NAME = "bbsshell"; // Default: "bbsshell"
    /** BBS Shell Github organization url */
    public static final String BBSSHELL_GITHUB_ORGANIZATION_URL = "https://github.com" + "/" + BBSSHELL_GITHUB_ORGANIZATION_NAME; // Default: "https://github.com/bbsshell"

    /** F-Droid packages base url */
    public static final String FDROID_PACKAGES_BASE_URL = "https://f-droid.org/en/packages"; // Default: "https://f-droid.org/en/packages"





    /*
     * BBS Shell app package names and urls.
     */

    /** BBS Shell app name */
    public static final String BBSSHELL_APP_NAME = "BBS Shell"; // Default: "BBS Shell"
    /** BBS Shell package name */
    public static final String BBSSHELL_PACKAGE_NAME = "kz.bbsshell.app"; // Default: "kz.bbsshell.app"
    /** BBS Shell Github repo name */
    public static final String BBSSHELL_GITHUB_REPO_NAME = "bbsshell-app"; // Default: "bbsshell-app"
    /** BBS Shell Github repo url */
    public static final String BBSSHELL_GITHUB_REPO_URL = BBSSHELL_GITHUB_ORGANIZATION_URL + "/" + BBSSHELL_GITHUB_REPO_NAME; // Default: "https://github.com/bbsshell/bbsshell-app"
    /** BBS Shell Github issues repo url */
    public static final String BBSSHELL_GITHUB_ISSUES_REPO_URL = BBSSHELL_GITHUB_REPO_URL + "/issues"; // Default: "https://github.com/bbsshell/bbsshell-app/issues"
    /** BBS Shell F-Droid package url */
    public static final String BBSSHELL_FDROID_PACKAGE_URL = FDROID_PACKAGES_BASE_URL + "/" + BBSSHELL_PACKAGE_NAME; // Default: "https://f-droid.org/en/packages/kz.bbsshell.app"







    /*
     * BBS Shell APK releases.
     */

    /** F-Droid APK release */
    public static final String APK_RELEASE_FDROID = "F-Droid"; // Default: "F-Droid"

    /** F-Droid APK release signing certificate SHA-256 digest */
    public static final String APK_RELEASE_FDROID_SIGNING_CERTIFICATE_SHA256_DIGEST = "228FB2CFE90831C1499EC3CCAF61E96E8E1CE70766B9474672CE427334D41C42"; // Default: "228FB2CFE90831C1499EC3CCAF61E96E8E1CE70766B9474672CE427334D41C42"

    /** Github APK release */
    public static final String APK_RELEASE_GITHUB = "Github"; // Default: "Github"

    /** Github APK release signing certificate SHA-256 digest */
    public static final String APK_RELEASE_GITHUB_SIGNING_CERTIFICATE_SHA256_DIGEST = "B6DA01480EEFD5FBF2CD3771B8D1021EC791304BDD6C4BF41D3FAABAD48EE5E1"; // Default: "B6DA01480EEFD5FBF2CD3771B8D1021EC791304BDD6C4BF41D3FAABAD48EE5E1"

    /** Google Play Store APK release */
    public static final String APK_RELEASE_GOOGLE_PLAYSTORE = "Google Play Store"; // Default: "Google Play Store"

    /** Google Play Store APK release signing certificate SHA-256 digest */
    public static final String APK_RELEASE_GOOGLE_PLAYSTORE_SIGNING_CERTIFICATE_SHA256_DIGEST = "738F0A30A04D3C8A1BE304AF18D0779BCF3EA88FB60808F657A3521861C2EBF9"; // Default: "738F0A30A04D3C8A1BE304AF18D0779BCF3EA88FB60808F657A3521861C2EBF9"





    /*
     * BBS Shell packages urls.
     */

    /** BBS Shell Packages Github repo name */
    public static final String BBSSHELL_PACKAGES_GITHUB_REPO_NAME = "bbsshell-packages"; // Default: "bbsshell-packages"
    /** BBS Shell Packages Github repo url */
    public static final String BBSSHELL_PACKAGES_GITHUB_REPO_URL = BBSSHELL_GITHUB_ORGANIZATION_URL + "/" + BBSSHELL_PACKAGES_GITHUB_REPO_NAME; // Default: "https://github.com/bbsshell/bbsshell-packages"
    /** BBS Shell Packages Github issues repo url */
    public static final String BBSSHELL_PACKAGES_GITHUB_ISSUES_REPO_URL = BBSSHELL_PACKAGES_GITHUB_REPO_URL + "/issues"; // Default: "https://github.com/bbsshell/bbsshell-packages/issues"


    /** BBS Shell Game Packages Github repo name */
    public static final String BBSSHELL_GAME_PACKAGES_GITHUB_REPO_NAME = "game-packages"; // Default: "game-packages"
    /** BBS Shell Game Packages Github repo url */
    public static final String BBSSHELL_GAME_PACKAGES_GITHUB_REPO_URL = BBSSHELL_GITHUB_ORGANIZATION_URL + "/" + BBSSHELL_GAME_PACKAGES_GITHUB_REPO_NAME; // Default: "https://github.com/bbsshell/game-packages"
    /** BBS Shell Game Packages Github issues repo url */
    public static final String BBSSHELL_GAME_PACKAGES_GITHUB_ISSUES_REPO_URL = BBSSHELL_GAME_PACKAGES_GITHUB_REPO_URL + "/issues"; // Default: "https://github.com/bbsshell/game-packages/issues"


    /** BBS Shell Science Packages Github repo name */
    public static final String BBSSHELL_SCIENCE_PACKAGES_GITHUB_REPO_NAME = "science-packages"; // Default: "science-packages"
    /** BBS Shell Science Packages Github repo url */
    public static final String BBSSHELL_SCIENCE_PACKAGES_GITHUB_REPO_URL = BBSSHELL_GITHUB_ORGANIZATION_URL + "/" + BBSSHELL_SCIENCE_PACKAGES_GITHUB_REPO_NAME; // Default: "https://github.com/bbsshell/science-packages"
    /** BBS Shell Science Packages Github issues repo url */
    public static final String BBSSHELL_SCIENCE_PACKAGES_GITHUB_ISSUES_REPO_URL = BBSSHELL_SCIENCE_PACKAGES_GITHUB_REPO_URL + "/issues"; // Default: "https://github.com/bbsshell/science-packages/issues"


    /** BBS Shell Root Packages Github repo name */
    public static final String BBSSHELL_ROOT_PACKAGES_GITHUB_REPO_NAME = "bbsshell-root-packages"; // Default: "bbsshell-root-packages"
    /** BBS Shell Root Packages Github repo url */
    public static final String BBSSHELL_ROOT_PACKAGES_GITHUB_REPO_URL = BBSSHELL_GITHUB_ORGANIZATION_URL + "/" + BBSSHELL_ROOT_PACKAGES_GITHUB_REPO_NAME; // Default: "https://github.com/bbsshell/bbsshell-root-packages"
    /** BBS Shell Root Packages Github issues repo url */
    public static final String BBSSHELL_ROOT_PACKAGES_GITHUB_ISSUES_REPO_URL = BBSSHELL_ROOT_PACKAGES_GITHUB_REPO_URL + "/issues"; // Default: "https://github.com/bbsshell/bbsshell-root-packages/issues"


    /** BBS Shell Unstable Packages Github repo name */
    public static final String BBSSHELL_UNSTABLE_PACKAGES_GITHUB_REPO_NAME = "unstable-packages"; // Default: "unstable-packages"
    /** BBS Shell Unstable Packages Github repo url */
    public static final String BBSSHELL_UNSTABLE_PACKAGES_GITHUB_REPO_URL = BBSSHELL_GITHUB_ORGANIZATION_URL + "/" + BBSSHELL_UNSTABLE_PACKAGES_GITHUB_REPO_NAME; // Default: "https://github.com/bbsshell/unstable-packages"
    /** BBS Shell Unstable Packages Github issues repo url */
    public static final String BBSSHELL_UNSTABLE_PACKAGES_GITHUB_ISSUES_REPO_URL = BBSSHELL_UNSTABLE_PACKAGES_GITHUB_REPO_URL + "/issues"; // Default: "https://github.com/bbsshell/unstable-packages/issues"


    /** BBS Shell X11 Packages Github repo name */
    public static final String BBSSHELL_X11_PACKAGES_GITHUB_REPO_NAME = "x11-packages"; // Default: "x11-packages"
    /** BBS Shell X11 Packages Github repo url */
    public static final String BBSSHELL_X11_PACKAGES_GITHUB_REPO_URL = BBSSHELL_GITHUB_ORGANIZATION_URL + "/" + BBSSHELL_X11_PACKAGES_GITHUB_REPO_NAME; // Default: "https://github.com/bbsshell/x11-packages"
    /** BBS Shell X11 Packages Github issues repo url */
    public static final String BBSSHELL_X11_PACKAGES_GITHUB_ISSUES_REPO_URL = BBSSHELL_X11_PACKAGES_GITHUB_REPO_URL + "/issues"; // Default: "https://github.com/bbsshell/x11-packages/issues"





    /*
     * BBS Shell miscellaneous urls.
     */

    /** BBS Shell Site */
    public static final String BBSSHELL_SITE = BBSSHELL_APP_NAME + " Site"; // Default: "BBS Shell Site"

    /** BBS Shell Site url */
    public static final String BBSSHELL_SITE_URL = "https://bbsshell.example"; // Default: "https://bbsshell.example"

    /** BBS Shell Wiki */
    public static final String BBSSHELL_WIKI = BBSSHELL_APP_NAME + " Wiki"; // Default: "BBS Shell Wiki"

    /** BBS Shell Wiki url */
    public static final String BBSSHELL_WIKI_URL = "https://bbsshell.example/wiki"; // Default: "https://bbsshell.example/wiki"

    /** BBS Shell Github wiki repo url */
    public static final String BBSSHELL_GITHUB_WIKI_REPO_URL = BBSSHELL_GITHUB_REPO_URL + "/wiki"; // Default: "https://github.com/bbsshell/bbsshell-app/wiki"

    /** BBS Shell Packages wiki repo url */
    public static final String BBSSHELL_PACKAGES_GITHUB_WIKI_REPO_URL = BBSSHELL_PACKAGES_GITHUB_REPO_URL + "/wiki"; // Default: "https://github.com/bbsshell/bbsshell-packages/wiki"


    /** BBS Shell support email url */
    public static final String BBSSHELL_SUPPORT_EMAIL_URL = "support@bbsshell.example"; // Default: "support@bbsshell.example"

    /** BBS Shell support email mailto url */
    public static final String BBSSHELL_SUPPORT_EMAIL_MAILTO_URL = "mailto:" + BBSSHELL_SUPPORT_EMAIL_URL; // Default: "mailto:support@bbsshell.dev"


    /** BBS Shell Reddit subreddit */
    public static final String BBSSHELL_REDDIT_SUBREDDIT = "r/bbsshell"; // Default: "r/bbsshell"

    /** BBS Shell Reddit subreddit url */
    public static final String BBSSHELL_REDDIT_SUBREDDIT_URL = "https://bbsshell.example/community"; // Default: "https://bbsshell.example/community"


    /** BBS Shell donate url */
    public static final String BBSSHELL_DONATE_URL = BBSSHELL_SITE_URL + "/donate"; // Default: "https://bbsshell.dev/donate"





    /*
     * BBS Shell app core directory paths.
     */

    /** BBS Shell app internal private app data directory path */
    @SuppressLint("SdCardPath")
    public static final String BBSSHELL_INTERNAL_PRIVATE_APP_DATA_DIR_PATH = "/data/data/" + BBSSHELL_PACKAGE_NAME; // Default: "/data/data/kz.bbsshell.app"
    /** BBS Shell app internal private app data directory */
    public static final File BBSSHELL_INTERNAL_PRIVATE_APP_DATA_DIR = new File(BBSSHELL_INTERNAL_PRIVATE_APP_DATA_DIR_PATH);



    /** BBS Shell app Files directory path */
    public static final String BBSSHELL_FILES_DIR_PATH = BBSSHELL_INTERNAL_PRIVATE_APP_DATA_DIR_PATH + "/files"; // Default: "/data/data/kz.bbsshell.app/files"
    /** BBS Shell app Files directory */
    public static final File BBSSHELL_FILES_DIR = new File(BBSSHELL_FILES_DIR_PATH);



    /** BBS Shell app $PREFIX directory path */
    public static final String BBSSHELL_PREFIX_DIR_PATH = BBSSHELL_FILES_DIR_PATH + "/usr"; // Default: "/data/data/kz.bbsshell.app/files/usr"
    /** BBS Shell app $PREFIX directory */
    public static final File BBSSHELL_PREFIX_DIR = new File(BBSSHELL_PREFIX_DIR_PATH);


    /** BBS Shell app $PREFIX/bin directory path */
    public static final String BBSSHELL_BIN_PREFIX_DIR_PATH = BBSSHELL_PREFIX_DIR_PATH + "/bin"; // Default: "/data/data/kz.bbsshell.app/files/usr/bin"
    /** BBS Shell app $PREFIX/bin directory */
    public static final File BBSSHELL_BIN_PREFIX_DIR = new File(BBSSHELL_BIN_PREFIX_DIR_PATH);


    /** BBS Shell app $PREFIX/etc directory path */
    public static final String BBSSHELL_ETC_PREFIX_DIR_PATH = BBSSHELL_PREFIX_DIR_PATH + "/etc"; // Default: "/data/data/kz.bbsshell.app/files/usr/etc"
    /** BBS Shell app $PREFIX/etc directory */
    public static final File BBSSHELL_ETC_PREFIX_DIR = new File(BBSSHELL_ETC_PREFIX_DIR_PATH);


    /** BBS Shell app $PREFIX/include directory path */
    public static final String BBSSHELL_INCLUDE_PREFIX_DIR_PATH = BBSSHELL_PREFIX_DIR_PATH + "/include"; // Default: "/data/data/kz.bbsshell.app/files/usr/include"
    /** BBS Shell app $PREFIX/include directory */
    public static final File BBSSHELL_INCLUDE_PREFIX_DIR = new File(BBSSHELL_INCLUDE_PREFIX_DIR_PATH);


    /** BBS Shell app $PREFIX/lib directory path */
    public static final String BBSSHELL_LIB_PREFIX_DIR_PATH = BBSSHELL_PREFIX_DIR_PATH + "/lib"; // Default: "/data/data/kz.bbsshell.app/files/usr/lib"
    /** BBS Shell app $PREFIX/lib directory */
    public static final File BBSSHELL_LIB_PREFIX_DIR = new File(BBSSHELL_LIB_PREFIX_DIR_PATH);


    /** BBS Shell app $PREFIX/libexec directory path */
    public static final String BBSSHELL_LIBEXEC_PREFIX_DIR_PATH = BBSSHELL_PREFIX_DIR_PATH + "/libexec"; // Default: "/data/data/kz.bbsshell.app/files/usr/libexec"
    /** BBS Shell app $PREFIX/libexec directory */
    public static final File BBSSHELL_LIBEXEC_PREFIX_DIR = new File(BBSSHELL_LIBEXEC_PREFIX_DIR_PATH);


    /** BBS Shell app $PREFIX/share directory path */
    public static final String BBSSHELL_SHARE_PREFIX_DIR_PATH = BBSSHELL_PREFIX_DIR_PATH + "/share"; // Default: "/data/data/kz.bbsshell.app/files/usr/share"
    /** BBS Shell app $PREFIX/share directory */
    public static final File BBSSHELL_SHARE_PREFIX_DIR = new File(BBSSHELL_SHARE_PREFIX_DIR_PATH);


    /** BBS Shell app $PREFIX/tmp and $TMPDIR directory path */
    public static final String BBSSHELL_TMP_PREFIX_DIR_PATH = BBSSHELL_PREFIX_DIR_PATH + "/tmp"; // Default: "/data/data/kz.bbsshell.app/files/usr/tmp"
    /** BBS Shell app $PREFIX/tmp and $TMPDIR directory */
    public static final File BBSSHELL_TMP_PREFIX_DIR = new File(BBSSHELL_TMP_PREFIX_DIR_PATH);


    /** BBS Shell app $PREFIX/var directory path */
    public static final String BBSSHELL_VAR_PREFIX_DIR_PATH = BBSSHELL_PREFIX_DIR_PATH + "/var"; // Default: "/data/data/kz.bbsshell.app/files/usr/var"
    /** BBS Shell app $PREFIX/var directory */
    public static final File BBSSHELL_VAR_PREFIX_DIR = new File(BBSSHELL_VAR_PREFIX_DIR_PATH);



    /** BBS Shell app usr-staging directory path */
    public static final String BBSSHELL_STAGING_PREFIX_DIR_PATH = BBSSHELL_FILES_DIR_PATH + "/usr-staging"; // Default: "/data/data/kz.bbsshell.app/files/usr-staging"
    /** BBS Shell app usr-staging directory */
    public static final File BBSSHELL_STAGING_PREFIX_DIR = new File(BBSSHELL_STAGING_PREFIX_DIR_PATH);



    /** BBS Shell app $HOME directory path */
    public static final String BBSSHELL_HOME_DIR_PATH = BBSSHELL_FILES_DIR_PATH + "/home"; // Default: "/data/data/kz.bbsshell.app/files/home"
    /** BBS Shell app $HOME directory */
    public static final File BBSSHELL_HOME_DIR = new File(BBSSHELL_HOME_DIR_PATH);


    /** BBS Shell app config home directory path */
    public static final String BBSSHELL_CONFIG_HOME_DIR_PATH = BBSSHELL_HOME_DIR_PATH + "/.config/bbsshell"; // Default: "/data/data/kz.bbsshell.app/files/home/.config/bbsshell"
    /** BBS Shell app config home directory */
    public static final File BBSSHELL_CONFIG_HOME_DIR = new File(BBSSHELL_CONFIG_HOME_DIR_PATH);


    /** BBS Shell app data home directory path */
    public static final String BBSSHELL_DATA_HOME_DIR_PATH = BBSSHELL_HOME_DIR_PATH + "/.bbsshell"; // Default: "/data/data/kz.bbsshell.app/files/home/.bbsshell"
    /** BBS Shell app data home directory */
    public static final File BBSSHELL_DATA_HOME_DIR = new File(BBSSHELL_DATA_HOME_DIR_PATH);


    /** BBS Shell app storage home directory path */
    public static final String BBSSHELL_STORAGE_HOME_DIR_PATH = BBSSHELL_HOME_DIR_PATH + "/storage"; // Default: "/data/data/kz.bbsshell.app/files/home/storage"
    /** BBS Shell app storage home directory */
    public static final File BBSSHELL_STORAGE_HOME_DIR = new File(BBSSHELL_STORAGE_HOME_DIR_PATH);





    /*
     * BBS Shell app preferences and properties file paths.
     */

    /** BBS Shell app default SharedPreferences file basename without extension */
    public static final String BBSSHELL_DEFAULT_PREFERENCES_FILE_BASENAME_WITHOUT_EXTENSION = BBSSHELL_PACKAGE_NAME + "_preferences"; // Default: "kz.bbsshell.app_preferences"



    /** BBS Shell app bbsshell.properties primary file path */
    public static final String BBSSHELL_PROPERTIES_PRIMARY_FILE_PATH = BBSSHELL_DATA_HOME_DIR_PATH + "/bbsshell.properties"; // Default: "/data/data/kz.bbsshell.app/files/home/.bbsshell/bbsshell.properties"
    /** BBS Shell app bbsshell.properties primary file */
    public static final File BBSSHELL_PROPERTIES_PRIMARY_FILE = new File(BBSSHELL_PROPERTIES_PRIMARY_FILE_PATH);

    /** BBS Shell app bbsshell.properties secondary file path */
    public static final String BBSSHELL_PROPERTIES_SECONDARY_FILE_PATH = BBSSHELL_CONFIG_HOME_DIR_PATH + "/bbsshell.properties"; // Default: "/data/data/kz.bbsshell.app/files/home/.config/bbsshell/bbsshell.properties"
    /** BBS Shell app bbsshell.properties secondary file */
    public static final File BBSSHELL_PROPERTIES_SECONDARY_FILE = new File(BBSSHELL_PROPERTIES_SECONDARY_FILE_PATH);




    /** BBS Shell app colors.properties file path */
    public static final String BBSSHELL_COLOR_PROPERTIES_FILE_PATH = BBSSHELL_DATA_HOME_DIR_PATH + "/colors.properties"; // Default: "/data/data/kz.bbsshell.app/files/home/.bbsshell/colors.properties"
    /** BBS Shell app colors.properties file */
    public static final File BBSSHELL_COLOR_PROPERTIES_FILE = new File(BBSSHELL_COLOR_PROPERTIES_FILE_PATH);

    /** BBS Shell app font.ttf file path */
    public static final String BBSSHELL_FONT_FILE_PATH = BBSSHELL_DATA_HOME_DIR_PATH + "/font.ttf"; // Default: "/data/data/kz.bbsshell.app/files/home/.bbsshell/font.ttf"
    /** BBS Shell app font.ttf file */
    public static final File BBSSHELL_FONT_FILE = new File(BBSSHELL_FONT_FILE_PATH);


    /** BBS Shell app and plugins crash log file path */
    public static final String BBSSHELL_CRASH_LOG_FILE_PATH = BBSSHELL_HOME_DIR_PATH + "/crash_log.md"; // Default: "/data/data/kz.bbsshell.app/files/home/crash_log.md"

    /** BBS Shell app and plugins crash log backup file path */
    public static final String BBSSHELL_CRASH_LOG_BACKUP_FILE_PATH = BBSSHELL_HOME_DIR_PATH + "/crash_log_backup.md"; // Default: "/data/data/kz.bbsshell.app/files/home/crash_log_backup.md"










    /*
     * BBS Shell app and plugins notification variables.
     */

    /** BBS Shell app notification channel id used by {@link BBSSHELL_APP.BBSSHELL_SERVICE} */
    public static final String BBSSHELL_APP_NOTIFICATION_CHANNEL_ID = "bbsshell_notification_channel";
    /** BBS Shell app notification channel name used by {@link BBSSHELL_APP.BBSSHELL_SERVICE} */
    public static final String BBSSHELL_APP_NOTIFICATION_CHANNEL_NAME = BbsShellConstants.BBSSHELL_APP_NAME + " App";
    /** BBS Shell app unique notification id used by {@link BBSSHELL_APP.BBSSHELL_SERVICE} */
    public static final int BBSSHELL_APP_NOTIFICATION_ID = 1337;

    /** BBS Shell app notification channel id used by {@link BBSSHELL_APP.RUN_COMMAND_SERVICE} */
    public static final String BBSSHELL_RUN_COMMAND_NOTIFICATION_CHANNEL_ID = "bbsshell_run_command_notification_channel";
    /** BBS Shell app notification channel name used by {@link BBSSHELL_APP.RUN_COMMAND_SERVICE} */
    public static final String BBSSHELL_RUN_COMMAND_NOTIFICATION_CHANNEL_NAME = BbsShellConstants.BBSSHELL_APP_NAME + " RunCommandService";
    /** BBS Shell app unique notification id used by {@link BBSSHELL_APP.RUN_COMMAND_SERVICE} */
    public static final int BBSSHELL_RUN_COMMAND_NOTIFICATION_ID = 1338;

    /** BBS Shell app notification channel id used for plugin command errors */
    public static final String BBSSHELL_PLUGIN_COMMAND_ERRORS_NOTIFICATION_CHANNEL_ID = "bbsshell_plugin_command_errors_notification_channel";
    /** BBS Shell app notification channel name used for plugin command errors */
    public static final String BBSSHELL_PLUGIN_COMMAND_ERRORS_NOTIFICATION_CHANNEL_NAME = BbsShellConstants.BBSSHELL_APP_NAME + " Plugin Commands Errors";

    /** BBS Shell app notification channel id used for crash reports */
    public static final String BBSSHELL_CRASH_REPORTS_NOTIFICATION_CHANNEL_ID = "bbsshell_crash_reports_notification_channel";
    /** BBS Shell app notification channel name used for crash reports */
    public static final String BBSSHELL_CRASH_REPORTS_NOTIFICATION_CHANNEL_NAME = BbsShellConstants.BBSSHELL_APP_NAME + " Crash Reports";







    /*
     * BBS Shell app and plugins miscellaneous variables.
     */

    /** Android OS permission declared by BBS Shell app in AndroidManifest.xml which can be requested by
     * 3rd party apps to run various commands in BBS Shell app context */
    public static final String PERMISSION_RUN_COMMAND = BBSSHELL_PACKAGE_NAME + ".permission.RUN_COMMAND"; // Default: "kz.bbsshell.app.permission.RUN_COMMAND"

    /** BBS Shell property defined in bbsshell.properties file as a secondary check to PERMISSION_RUN_COMMAND
     * to allow 3rd party apps to run various commands in BBS Shell app context */
    public static final String PROP_ALLOW_EXTERNAL_APPS = "allow-external-apps"; // Default: "allow-external-apps"
    /** Default value for {@link #PROP_ALLOW_EXTERNAL_APPS} */
    public static final String PROP_DEFAULT_VALUE_ALLOW_EXTERNAL_APPS = "false"; // Default: "false"

    /** The broadcast action sent when BBS Shell App opens */
    public static final String BROADCAST_BBSSHELL_OPENED = BBSSHELL_PACKAGE_NAME + ".app.OPENED";

    /** The Uri authority for BBS Shell app file shares */
    public static final String BBSSHELL_FILE_SHARE_URI_AUTHORITY = BBSSHELL_PACKAGE_NAME + ".files"; // Default: "kz.bbsshell.app.files"

    /** The normal comma character (U+002C, &comma;, &#44;, comma) */
    public static final String COMMA_NORMAL = ","; // Default: ","

    /** The alternate comma character (U+201A, &sbquo;, &#8218;, single low-9 quotation mark) that
     * may be used instead of {@link #COMMA_NORMAL} */
    public static final String COMMA_ALTERNATIVE = "‚"; // Default: "‚"






    /**
     * BBS Shell app constants.
     */
    public static final class BBSSHELL_APP {

        /** BBS Shell app core activity name. */
        public static final String BBSSHELL_ACTIVITY_NAME = BBSSHELL_PACKAGE_NAME + ".app.BbsShellActivity"; // Default: "kz.bbsshell.app.BbsShellActivity"

        /**
         * BBS Shell app core activity.
         */
        public static final class BBSSHELL_ACTIVITY {

            /** Intent extra for if bbsshell failsafe session needs to be started and is used by {@link BBSSHELL_ACTIVITY} and {@link BBSSHELL_SERVICE#ACTION_STOP_SERVICE} */
            public static final String EXTRA_FAILSAFE_SESSION = BbsShellConstants.BBSSHELL_PACKAGE_NAME + ".app.failsafe_session"; // Default: "kz.bbsshell.app.failsafe_session"


            /** Intent action to make bbsshell request storage permissions */
            public static final String ACTION_REQUEST_PERMISSIONS = BbsShellConstants.BBSSHELL_PACKAGE_NAME + ".app.request_storage_permissions"; // Default: "kz.bbsshell.app.request_storage_permissions"

            /** Intent action to make bbsshell reload its bbsshell session styling */
            public static final String ACTION_RELOAD_STYLE = BbsShellConstants.BBSSHELL_PACKAGE_NAME + ".app.reload_style"; // Default: "kz.bbsshell.app.reload_style"
            /** Intent {@code String} extra for what to reload for the BBSSHELL_ACTIVITY.ACTION_RELOAD_STYLE intent. This has been deperecated. */
            @Deprecated
            public static final String EXTRA_RELOAD_STYLE = BbsShellConstants.BBSSHELL_PACKAGE_NAME + ".app.reload_style"; // Default: "kz.bbsshell.app.reload_style"

        }





        /** BBS Shell app settings activity name. */
        public static final String BBSSHELL_SETTINGS_ACTIVITY_NAME = BBSSHELL_PACKAGE_NAME + ".app.activities.SettingsActivity"; // Default: "kz.bbsshell.app.activities.SettingsActivity"





        /** BBS Shell app core service name. */
        public static final String BBSSHELL_SERVICE_NAME = BBSSHELL_PACKAGE_NAME + ".app.BbsShellService"; // Default: "kz.bbsshell.app.BbsShellService"

        /**
         * BBS Shell app core service.
         */
        public static final class BBSSHELL_SERVICE {

            /** Intent action to stop BBSSHELL_SERVICE */
            public static final String ACTION_STOP_SERVICE = BBSSHELL_PACKAGE_NAME + ".service_stop"; // Default: "kz.bbsshell.app.service_stop"


            /** Intent action to make BBSSHELL_SERVICE acquire a wakelock */
            public static final String ACTION_WAKE_LOCK = BBSSHELL_PACKAGE_NAME + ".service_wake_lock"; // Default: "kz.bbsshell.app.service_wake_lock"


            /** Intent action to make BBSSHELL_SERVICE release wakelock */
            public static final String ACTION_WAKE_UNLOCK = BBSSHELL_PACKAGE_NAME + ".service_wake_unlock"; // Default: "kz.bbsshell.app.service_wake_unlock"


            /** Intent action to execute command with BBSSHELL_SERVICE */
            public static final String ACTION_SERVICE_EXECUTE = BBSSHELL_PACKAGE_NAME + ".service_execute"; // Default: "kz.bbsshell.app.service_execute"

            /** Uri scheme for paths sent via intent to BBSSHELL_SERVICE */
            public static final String URI_SCHEME_SERVICE_EXECUTE = BBSSHELL_PACKAGE_NAME + ".file"; // Default: "kz.bbsshell.app.file"
            /** Intent {@code String[]} extra for arguments to the executable of the command for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_ARGUMENTS = BBSSHELL_PACKAGE_NAME + ".execute.arguments"; // Default: "kz.bbsshell.app.execute.arguments"
            /** Intent {@code String} extra for stdin of the command for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_STDIN = BBSSHELL_PACKAGE_NAME + ".execute.stdin"; // Default: "kz.bbsshell.app.execute.stdin"
            /** Intent {@code String} extra for command current working directory for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_WORKDIR = BBSSHELL_PACKAGE_NAME + ".execute.cwd"; // Default: "kz.bbsshell.app.execute.cwd"
            /** Intent {@code boolean} extra for command background mode for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_BACKGROUND = BBSSHELL_PACKAGE_NAME + ".execute.background"; // Default: "kz.bbsshell.app.execute.background"
            /** Intent {@code String} extra for custom log level for background commands defined by {@link kz.bbsshell.shared.logger.Logger} for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_BACKGROUND_CUSTOM_LOG_LEVEL = BBSSHELL_PACKAGE_NAME + ".execute.background_custom_log_level"; // Default: "kz.bbsshell.app.execute.background_custom_log_level"
            /** Intent {@code String} extra for session action for foreground commands for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_SESSION_ACTION = BBSSHELL_PACKAGE_NAME + ".execute.session_action"; // Default: "kz.bbsshell.app.execute.session_action"
            /** Intent {@code String} extra for label of the command for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_COMMAND_LABEL = BBSSHELL_PACKAGE_NAME + ".execute.command_label"; // Default: "kz.bbsshell.app.execute.command_label"
            /** Intent markdown {@code String} extra for description of the command for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_COMMAND_DESCRIPTION = BBSSHELL_PACKAGE_NAME + ".execute.command_description"; // Default: "kz.bbsshell.app.execute.command_description"
            /** Intent markdown {@code String} extra for help of the command for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_COMMAND_HELP = BBSSHELL_PACKAGE_NAME + ".execute.command_help"; // Default: "kz.bbsshell.app.execute.command_help"
            /** Intent markdown {@code String} extra for help of the plugin API for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent (Internal Use Only) */
            public static final String EXTRA_PLUGIN_API_HELP = BBSSHELL_PACKAGE_NAME + ".execute.plugin_api_help"; // Default: "kz.bbsshell.app.execute.plugin_help"
            /** Intent {@code Parcelable} extra for the pending intent that should be sent with the
             * result of the execution command to the execute command caller for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_PENDING_INTENT = "pendingIntent"; // Default: "pendingIntent"
            /** Intent {@code String} extra for the directory path in which to write the result of the
             * execution command for the execute command caller for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_RESULT_DIRECTORY = BBSSHELL_PACKAGE_NAME + ".execute.result_directory"; // Default: "kz.bbsshell.app.execute.result_directory"
            /** Intent {@code boolean} extra for whether the result should be written to a single file
             * or multiple files (err, errmsg, stdout, stderr, exit_code) in
             * {@link #EXTRA_RESULT_DIRECTORY} for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_RESULT_SINGLE_FILE = BBSSHELL_PACKAGE_NAME + ".execute.result_single_file"; // Default: "kz.bbsshell.app.execute.result_single_file"
            /** Intent {@code String} extra for the basename of the result file that should be created
             * in {@link #EXTRA_RESULT_DIRECTORY} if {@link #EXTRA_RESULT_SINGLE_FILE} is {@code true}
             * for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_RESULT_FILE_BASENAME = BBSSHELL_PACKAGE_NAME + ".execute.result_file_basename"; // Default: "kz.bbsshell.app.execute.result_file_basename"
            /** Intent {@code String} extra for the output {@link Formatter} format of the
             * {@link #EXTRA_RESULT_FILE_BASENAME} result file for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_RESULT_FILE_OUTPUT_FORMAT = BBSSHELL_PACKAGE_NAME + ".execute.result_file_output_format"; // Default: "kz.bbsshell.app.execute.result_file_output_format"
            /** Intent {@code String} extra for the error {@link Formatter} format of the
             * {@link #EXTRA_RESULT_FILE_BASENAME} result file for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_RESULT_FILE_ERROR_FORMAT = BBSSHELL_PACKAGE_NAME + ".execute.result_file_error_format"; // Default: "kz.bbsshell.app.execute.result_file_error_format"
            /** Intent {@code String} extra for the optional suffix of the result files that should
             * be created in {@link #EXTRA_RESULT_DIRECTORY} if {@link #EXTRA_RESULT_SINGLE_FILE} is
             * {@code false} for the BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent */
            public static final String EXTRA_RESULT_FILES_SUFFIX = BBSSHELL_PACKAGE_NAME + ".execute.result_files_suffix"; // Default: "kz.bbsshell.app.execute.result_files_suffix"



            /** The value for {@link #EXTRA_SESSION_ACTION} extra that will set the new session as
             * the current session and will start {@link BBSSHELL_ACTIVITY} if its not running to bring
             * the new session to foreground.
             */
            public static final int VALUE_EXTRA_SESSION_ACTION_SWITCH_TO_NEW_SESSION_AND_OPEN_ACTIVITY = 0;

            /** The value for {@link #EXTRA_SESSION_ACTION} extra that will keep any existing session
             * as the current session and will start {@link BBSSHELL_ACTIVITY} if its not running to
             * bring the existing session to foreground. The new session will be added to the left
             * sidebar in the sessions list.
             */
            public static final int VALUE_EXTRA_SESSION_ACTION_KEEP_CURRENT_SESSION_AND_OPEN_ACTIVITY = 1;

            /** The value for {@link #EXTRA_SESSION_ACTION} extra that will set the new session as
             * the current session but will not start {@link BBSSHELL_ACTIVITY} if its not running
             * and session(s) will be seen in BBS Shell notification and can be clicked to bring new
             * session to foreground. If the {@link BBSSHELL_ACTIVITY} is already running, then this
             * will behave like {@link #VALUE_EXTRA_SESSION_ACTION_KEEP_CURRENT_SESSION_AND_OPEN_ACTIVITY}.
             */
            public static final int VALUE_EXTRA_SESSION_ACTION_SWITCH_TO_NEW_SESSION_AND_DONT_OPEN_ACTIVITY = 2;

            /** The value for {@link #EXTRA_SESSION_ACTION} extra that will keep any existing session
             * as the current session but will not start {@link BBSSHELL_ACTIVITY} if its not running
             * and session(s) will be seen in BBS Shell notification and can be clicked to bring
             * existing session to foreground. If the {@link BBSSHELL_ACTIVITY} is already running,
             * then this will behave like {@link #VALUE_EXTRA_SESSION_ACTION_KEEP_CURRENT_SESSION_AND_OPEN_ACTIVITY}.
             */
            public static final int VALUE_EXTRA_SESSION_ACTION_KEEP_CURRENT_SESSION_AND_DONT_OPEN_ACTIVITY = 3;

            /** The minimum allowed value for {@link #EXTRA_SESSION_ACTION}. */
            public static final int MIN_VALUE_EXTRA_SESSION_ACTION = VALUE_EXTRA_SESSION_ACTION_SWITCH_TO_NEW_SESSION_AND_OPEN_ACTIVITY;

            /** The maximum allowed value for {@link #EXTRA_SESSION_ACTION}. */
            public static final int MAX_VALUE_EXTRA_SESSION_ACTION = VALUE_EXTRA_SESSION_ACTION_KEEP_CURRENT_SESSION_AND_DONT_OPEN_ACTIVITY;


            /** Intent {@code Bundle} extra to store result of execute command that is sent back for the
             * BBSSHELL_SERVICE.ACTION_SERVICE_EXECUTE intent if the {@link #EXTRA_PENDING_INTENT} is not
             * {@code null} */
            public static final String EXTRA_PLUGIN_RESULT_BUNDLE = "result"; // Default: "result"
            /** Intent {@code String} extra for stdout value of execute command of the {@link #EXTRA_PLUGIN_RESULT_BUNDLE} */
            public static final String EXTRA_PLUGIN_RESULT_BUNDLE_STDOUT = "stdout"; // Default: "stdout"
            /** Intent {@code String} extra for original length of stdout value of execute command of the {@link #EXTRA_PLUGIN_RESULT_BUNDLE} */
            public static final String EXTRA_PLUGIN_RESULT_BUNDLE_STDOUT_ORIGINAL_LENGTH = "stdout_original_length"; // Default: "stdout_original_length"
            /** Intent {@code String} extra for stderr value of execute command of the {@link #EXTRA_PLUGIN_RESULT_BUNDLE} */
            public static final String EXTRA_PLUGIN_RESULT_BUNDLE_STDERR = "stderr"; // Default: "stderr"
            /** Intent {@code String} extra for original length of stderr value of execute command of the {@link #EXTRA_PLUGIN_RESULT_BUNDLE} */
            public static final String EXTRA_PLUGIN_RESULT_BUNDLE_STDERR_ORIGINAL_LENGTH = "stderr_original_length"; // Default: "stderr_original_length"
            /** Intent {@code int} extra for exit code value of execute command of the {@link #EXTRA_PLUGIN_RESULT_BUNDLE} */
            public static final String EXTRA_PLUGIN_RESULT_BUNDLE_EXIT_CODE = "exitCode"; // Default: "exitCode"
            /** Intent {@code int} extra for err value of execute command of the {@link #EXTRA_PLUGIN_RESULT_BUNDLE} */
            public static final String EXTRA_PLUGIN_RESULT_BUNDLE_ERR = "err"; // Default: "err"
            /** Intent {@code String} extra for errmsg value of execute command of the {@link #EXTRA_PLUGIN_RESULT_BUNDLE} */
            public static final String EXTRA_PLUGIN_RESULT_BUNDLE_ERRMSG = "errmsg"; // Default: "errmsg"

        }





        /** BBS Shell app run command service name. */
        public static final String RUN_COMMAND_SERVICE_NAME = BBSSHELL_PACKAGE_NAME + ".app.RunCommandService"; // BBS Shell app service to receive commands from 3rd party apps "kz.bbsshell.app.RunCommandService"

        /**
         * BBS Shell app run command service to receive commands sent by 3rd party apps.
         */
        public static final class RUN_COMMAND_SERVICE {

            /** BBS Shell RUN_COMMAND Intent help url */
            public static final String RUN_COMMAND_API_HELP_URL = BBSSHELL_GITHUB_WIKI_REPO_URL + "/RUN_COMMAND-Intent"; // Default: "https://github.com/bbsshell/bbsshell-app/wiki/RUN_COMMAND-Intent"


            /** Intent action to execute command with RUN_COMMAND_SERVICE */
            public static final String ACTION_RUN_COMMAND = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND"; // Default: "kz.bbsshell.app.RUN_COMMAND"

            /** Intent {@code String} extra for absolute path of command for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_COMMAND_PATH = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_PATH"; // Default: "kz.bbsshell.app.RUN_COMMAND_PATH"
            /** Intent {@code String[]} extra for arguments to the executable of the command for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_ARGUMENTS = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_ARGUMENTS"; // Default: "kz.bbsshell.app.RUN_COMMAND_ARGUMENTS"
            /** Intent {@code boolean} extra for whether to replace comma alternative characters in arguments with comma characters for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_REPLACE_COMMA_ALTERNATIVE_CHARS_IN_ARGUMENTS = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_REPLACE_COMMA_ALTERNATIVE_CHARS_IN_ARGUMENTS"; // Default: "kz.bbsshell.app.RUN_COMMAND_REPLACE_COMMA_ALTERNATIVE_CHARS_IN_ARGUMENTS"
            /** Intent {@code String} extra for the comma alternative characters in arguments that should be replaced instead of the default {@link #COMMA_ALTERNATIVE} for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_COMMA_ALTERNATIVE_CHARS_IN_ARGUMENTS = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_COMMA_ALTERNATIVE_CHARS_IN_ARGUMENTS"; // Default: "kz.bbsshell.app.RUN_COMMAND_COMMA_ALTERNATIVE_CHARS_IN_ARGUMENTS"

            /** Intent {@code String} extra for stdin of the command for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_STDIN = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_STDIN"; // Default: "kz.bbsshell.app.RUN_COMMAND_STDIN"
            /** Intent {@code String} extra for current working directory of command for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_WORKDIR = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_WORKDIR"; // Default: "kz.bbsshell.app.RUN_COMMAND_WORKDIR"
            /** Intent {@code boolean} extra for whether to run command in background or foreground terminal session for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_BACKGROUND = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_BACKGROUND"; // Default: "kz.bbsshell.app.RUN_COMMAND_BACKGROUND"
            /** Intent {@code String} extra for custom log level for background commands defined by {@link kz.bbsshell.shared.logger.Logger} for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_BACKGROUND_CUSTOM_LOG_LEVEL = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_BACKGROUND_CUSTOM_LOG_LEVEL"; // Default: "kz.bbsshell.app.RUN_COMMAND_BACKGROUND_CUSTOM_LOG_LEVEL"
            /** Intent {@code String} extra for session action of foreground commands for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_SESSION_ACTION = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_SESSION_ACTION"; // Default: "kz.bbsshell.app.RUN_COMMAND_SESSION_ACTION"
            /** Intent {@code String} extra for label of the command for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_COMMAND_LABEL = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_COMMAND_LABEL"; // Default: "kz.bbsshell.app.RUN_COMMAND_COMMAND_LABEL"
            /** Intent markdown {@code String} extra for description of the command for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_COMMAND_DESCRIPTION = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_COMMAND_DESCRIPTION"; // Default: "kz.bbsshell.app.RUN_COMMAND_COMMAND_DESCRIPTION"
            /** Intent markdown {@code String} extra for help of the command for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_COMMAND_HELP = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_COMMAND_HELP"; // Default: "kz.bbsshell.app.RUN_COMMAND_COMMAND_HELP"
            /** Intent {@code Parcelable} extra for the pending intent that should be sent with the result of the execution command to the execute command caller for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_PENDING_INTENT = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_PENDING_INTENT"; // Default: "kz.bbsshell.app.RUN_COMMAND_PENDING_INTENT"
            /** Intent {@code String} extra for the directory path in which to write the result of
             * the execution command for the execute command caller for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_RESULT_DIRECTORY = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_RESULT_DIRECTORY"; // Default: "kz.bbsshell.app.RUN_COMMAND_RESULT_DIRECTORY"
            /** Intent {@code boolean} extra for whether the result should be written to a single file
             * or multiple files (err, errmsg, stdout, stderr, exit_code) in
             * {@link #EXTRA_RESULT_DIRECTORY} for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_RESULT_SINGLE_FILE = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_RESULT_SINGLE_FILE"; // Default: "kz.bbsshell.app.RUN_COMMAND_RESULT_SINGLE_FILE"
            /** Intent {@code String} extra for the basename of the result file that should be created
             * in {@link #EXTRA_RESULT_DIRECTORY} if {@link #EXTRA_RESULT_SINGLE_FILE} is {@code true}
             * for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_RESULT_FILE_BASENAME = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_RESULT_FILE_BASENAME"; // Default: "kz.bbsshell.app.RUN_COMMAND_RESULT_FILE_BASENAME"
            /** Intent {@code String} extra for the output {@link Formatter} format of the
             * {@link #EXTRA_RESULT_FILE_BASENAME} result file for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_RESULT_FILE_OUTPUT_FORMAT = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_RESULT_FILE_OUTPUT_FORMAT"; // Default: "kz.bbsshell.app.RUN_COMMAND_RESULT_FILE_OUTPUT_FORMAT"
            /** Intent {@code String} extra for the error {@link Formatter} format of the
             * {@link #EXTRA_RESULT_FILE_BASENAME} result file for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_RESULT_FILE_ERROR_FORMAT = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_RESULT_FILE_ERROR_FORMAT"; // Default: "kz.bbsshell.app.RUN_COMMAND_RESULT_FILE_ERROR_FORMAT"
            /** Intent {@code String} extra for the optional suffix of the result files that should be
             * created in {@link #EXTRA_RESULT_DIRECTORY} if {@link #EXTRA_RESULT_SINGLE_FILE} is
             * {@code false} for the RUN_COMMAND_SERVICE.ACTION_RUN_COMMAND intent */
            public static final String EXTRA_RESULT_FILES_SUFFIX = BBSSHELL_PACKAGE_NAME + ".RUN_COMMAND_RESULT_FILES_SUFFIX"; // Default: "kz.bbsshell.app.RUN_COMMAND_RESULT_FILES_SUFFIX"

        }
    }





    /**
     * BBS Shell class to send back results of commands to their callers like plugin or 3rd party apps.
     */
    public static final class RESULT_SENDER {

        /*
         * The default `Formatter` format strings to use for `ResultConfig#resultFileBasename`
         * if `ResultConfig#resultSingleFile` is `true`.
         */

        /** The {@link Formatter} format string for success if only `stdout` needs to be written to
         * {@link ResultConfig#resultFileBasename} where `stdout` maps to `%1$s`.
         * This is used when `err` equals {@link Errno#ERRNO_SUCCESS} (-1) and `stderr` is empty
         * and `exit_code` equals `0` and {@link ResultConfig#resultFileOutputFormat} is not passed. */
        public static final String FORMAT_SUCCESS_STDOUT = "%1$s%n";
        /** The {@link Formatter} format string for success if `stdout` and `exit_code` need to be written to
         * {@link ResultConfig#resultFileBasename} where `stdout` maps to `%1$s` and `exit_code` to `%2$s`.
         * This is used when `err` equals {@link Errno#ERRNO_SUCCESS} (-1) and `stderr` is empty
         * and `exit_code` does not equal `0` and {@link ResultConfig#resultFileOutputFormat} is not passed.
         * The exit code will be placed in a markdown inline code. */
        public static final String FORMAT_SUCCESS_STDOUT__EXIT_CODE = "%1$s%n%n%n%nexit_code=%2$s%n";
        /** The {@link Formatter} format string for success if `stdout`, `stderr` and `exit_code` need to be
         * written to {@link ResultConfig#resultFileBasename} where `stdout` maps to `%1$s`, `stderr`
         * maps to `%2$s` and `exit_code` to `%3$s`.
         * This is used when `err` equals {@link Errno#ERRNO_SUCCESS} (-1) and `stderr` is not empty
         * and {@link ResultConfig#resultFileOutputFormat} is not passed.
         * The stdout and stderr will be placed in a markdown code block. The exit code will be placed
         * in a markdown inline code. The surrounding backticks will be 3 more than the consecutive
         * backticks in any parameter itself for code blocks. */
        public static final String FORMAT_SUCCESS_STDOUT__STDERR__EXIT_CODE = "stdout=%n%1$s%n%n%n%nstderr=%n%2$s%n%n%n%nexit_code=%3$s%n";
        /** The {@link Formatter} format string for failure if `err`, `errmsg`(`error`), `stdout`,
         * `stderr` and `exit_code` need to be written to {@link ResultConfig#resultFileBasename} where
         * `err` maps to `%1$s`, `errmsg` maps to `%2$s`, `stdout` maps
         * to `%3$s`, `stderr` to `%4$s` and `exit_code` maps to `%5$s`.
         * Do not define an argument greater than `5`, like `%6$s` if you change this value since it will
         * raise {@link IllegalFormatException}.
         * This is used when `err` does not equal {@link Errno#ERRNO_SUCCESS} (-1) and
         * {@link ResultConfig#resultFileErrorFormat} is not passed.
         * The errmsg, stdout and stderr will be placed in a markdown code block. The err and exit code
         * will be placed in a markdown inline code. The surrounding backticks will be 3 more than
         * the consecutive backticks in any parameter itself for code blocks. The stdout, stderr
         * and exit code may be empty without any surrounding backticks if not set. */
        public static final String FORMAT_FAILED_ERR__ERRMSG__STDOUT__STDERR__EXIT_CODE = "err=%1$s%n%n%n%nerrmsg=%n%2$s%n%n%n%nstdout=%n%3$s%n%n%n%nstderr=%n%4$s%n%n%n%nexit_code=%5$s%n";



        /*
         * The default prefixes to use for result files under `ResultConfig#resultDirectoryPath`
         * if `ResultConfig#resultSingleFile` is `false`.
         */

        /** The prefix for the err result file. */
        public static final String RESULT_FILE_ERR_PREFIX = "err";
        /** The prefix for the errmsg result file. */
        public static final String RESULT_FILE_ERRMSG_PREFIX = "errmsg";
        /** The prefix for the stdout result file. */
        public static final String RESULT_FILE_STDOUT_PREFIX = "stdout";
        /** The prefix for the stderr result file. */
        public static final String RESULT_FILE_STDERR_PREFIX = "stderr";
        /** The prefix for the exitCode result file. */
        public static final String RESULT_FILE_EXIT_CODE_PREFIX = "exit_code";

    }

}
