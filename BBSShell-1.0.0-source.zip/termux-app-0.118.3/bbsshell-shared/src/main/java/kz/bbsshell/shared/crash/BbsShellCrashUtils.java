package kz.bbsshell.shared.crash;

import android.content.Context;

import androidx.annotation.NonNull;

import kz.bbsshell.shared.core.BbsShellConstants;
import kz.bbsshell.shared.core.BbsShellUtils;

public class BbsShellCrashUtils implements CrashHandler.CrashHandlerClient {

    /**
     * Set default uncaught crash handler of current thread to {@link CrashHandler} for BbsShell app
     * and its plugin to log crashes at {@link BbsShellConstants#BBSSHELL_CRASH_LOG_FILE_PATH}.
     */
    public static void setCrashHandler(@NonNull final Context context) {
        CrashHandler.setCrashHandler(context, new BbsShellCrashUtils());
    }

    @NonNull
    @Override
    public String getCrashLogFilePath(Context context) {
        return BbsShellConstants.BBSSHELL_CRASH_LOG_FILE_PATH;
    }

    @Override
    public String getAppInfoMarkdownString(Context context) {
        return BbsShellUtils.getAppInfoMarkdownString(context, true);
    }

}
