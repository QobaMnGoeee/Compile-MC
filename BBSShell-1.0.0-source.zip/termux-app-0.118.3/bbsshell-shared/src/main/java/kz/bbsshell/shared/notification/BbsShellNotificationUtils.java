package kz.bbsshell.shared.notification;

import android.content.Context;

import kz.bbsshell.shared.settings.preferences.BbsShellAppSharedPreferences;
import kz.bbsshell.shared.settings.preferences.BbsShellPreferenceConstants;
import kz.bbsshell.shared.core.BbsShellConstants;

public class BbsShellNotificationUtils {
    /**
     * Try to get the next unique notification id that isn't already being used by the app.
     *
     * BbsShell app and its plugin must use unique notification ids from the same pool due to usage of android:sharedUserId.
     * https://commonsware.com/blog/2017/06/07/jobscheduler-job-ids-libraries.html
     *
     * @param context The {@link Context} for operations.
     * @return Returns the notification id that should be safe to use.
     */
    public synchronized static int getNextNotificationId(final Context context) {
        if (context == null) return BbsShellPreferenceConstants.BBSSHELL_APP.DEFAULT_VALUE_KEY_LAST_NOTIFICATION_ID;

        BbsShellAppSharedPreferences preferences = BbsShellAppSharedPreferences.build(context);
        if (preferences == null) return BbsShellPreferenceConstants.BBSSHELL_APP.DEFAULT_VALUE_KEY_LAST_NOTIFICATION_ID;

        int lastNotificationId = preferences.getLastNotificationId();

        int nextNotificationId = lastNotificationId + 1;
        while(nextNotificationId == BbsShellConstants.BBSSHELL_APP_NOTIFICATION_ID || nextNotificationId == BbsShellConstants.BBSSHELL_RUN_COMMAND_NOTIFICATION_ID) {
            nextNotificationId++;
        }

        if (nextNotificationId == Integer.MAX_VALUE || nextNotificationId < 0)
            nextNotificationId = BbsShellPreferenceConstants.BBSSHELL_APP.DEFAULT_VALUE_KEY_LAST_NOTIFICATION_ID;

        preferences.setLastNotificationId(nextNotificationId);
        return nextNotificationId;
    }
}
