package kz.bbsshell.shared.shell;

import android.content.Context;

import androidx.annotation.NonNull;

public class BbsShellShellEnvironmentClient implements ShellEnvironmentClient {

    @NonNull
    @Override
    public String getDefaultWorkingDirectoryPath() {
        return BbsShellShellUtils.getDefaultWorkingDirectoryPath();
    }

    @NonNull
    @Override
    public String getDefaultBinPath() {
        return BbsShellShellUtils.getDefaultBinPath();
    }

    @NonNull
    @Override
    public String[] buildEnvironment(Context currentPackageContext, boolean isFailSafe, String workingDirectory) {
        return BbsShellShellUtils.buildEnvironment(currentPackageContext, isFailSafe, workingDirectory);
    }

    @NonNull
    @Override
    public String[] setupProcessArgs(@NonNull String fileToExecute, String[] arguments) {
        return BbsShellShellUtils.setupProcessArgs(fileToExecute, arguments);
    }

}
