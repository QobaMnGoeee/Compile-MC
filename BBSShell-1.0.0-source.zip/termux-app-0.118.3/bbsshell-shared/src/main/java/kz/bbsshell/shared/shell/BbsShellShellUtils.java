package kz.bbsshell.shared.shell;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;

import androidx.annotation.NonNull;

import kz.bbsshell.shared.android.SELinuxUtils;
import kz.bbsshell.shared.data.DataUtils;
import kz.bbsshell.shared.models.errors.Error;
import kz.bbsshell.shared.core.BbsShellConstants;
import kz.bbsshell.shared.file.FileUtils;
import kz.bbsshell.shared.logger.Logger;
import kz.bbsshell.shared.packages.PackageUtils;
import kz.bbsshell.shared.core.BbsShellUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BbsShellShellUtils {

    public static String BBSSHELL_VERSION_NAME;
    public static String BBSSHELL_IS_DEBUGGABLE_BUILD;
    public static String BBSSHELL_APP_PID;
    public static String BBSSHELL_APK_RELEASE;

    public static String getDefaultWorkingDirectoryPath() {
        return BbsShellConstants.BBSSHELL_HOME_DIR_PATH;
    }

    public static String getDefaultBinPath() {
        return BbsShellConstants.BBSSHELL_BIN_PREFIX_DIR_PATH;
    }

    public static String[] buildEnvironment(Context currentPackageContext, boolean isFailSafe, String workingDirectory) {
        BbsShellConstants.BBSSHELL_HOME_DIR.mkdirs();

        if (workingDirectory == null || workingDirectory.isEmpty())
            workingDirectory = getDefaultWorkingDirectoryPath();

        List<String> environment = new ArrayList<>();

        loadBbsShellEnvVariables(currentPackageContext);

        if (BBSSHELL_VERSION_NAME != null)
            environment.add("BBSSHELL_VERSION=" + BBSSHELL_VERSION_NAME);
        if (BBSSHELL_IS_DEBUGGABLE_BUILD != null)
            environment.add("BBSSHELL_IS_DEBUGGABLE_BUILD=" + BBSSHELL_IS_DEBUGGABLE_BUILD);
        if (BBSSHELL_APP_PID != null)
            environment.add("BBSSHELL_APP_PID=" + BBSSHELL_APP_PID);
        if (BBSSHELL_APK_RELEASE != null)
            environment.add("BBSSHELL_APK_RELEASE=" + BBSSHELL_APK_RELEASE);



        environment.add("TERM=xterm-256color");
        environment.add("COLORTERM=truecolor");

        try {
            ApplicationInfo applicationInfo = currentPackageContext.getPackageManager().getApplicationInfo(
                BbsShellConstants.BBSSHELL_PACKAGE_NAME, 0);
            if (applicationInfo != null && !applicationInfo.enabled) {
                applicationInfo = null;
            }

            if (applicationInfo != null) {
                environment.add("BBSSHELL_APP__DATA_DIR=" + applicationInfo.dataDir);
                environment.add("BBSSHELL_APP__LEGACY_DATA_DIR=" + "/data/data/" + applicationInfo.packageName);

                environment.add("BBSSHELL_APP__SE_FILE_CONTEXT=" + SELinuxUtils.getFileContext(applicationInfo.dataDir));

                String seInfoUser = PackageUtils.getApplicationInfoSeInfoUserForPackage(applicationInfo);
                environment.add("BBSSHELL_APP__SE_INFO=" + PackageUtils.getApplicationInfoSeInfoForPackage(applicationInfo) +
                    (DataUtils.isNullOrEmpty(seInfoUser) ? "" : seInfoUser));
            }

        } catch (final Exception e) {
            // Ignore
        }

        environment.add("BBSSHELL__ROOTFS_DIR=" + BbsShellConstants.BBSSHELL_FILES_DIR_PATH);
        environment.add("HOME=" + BbsShellConstants.BBSSHELL_HOME_DIR_PATH);
        environment.add("BBSSHELL__HOME=" + BbsShellConstants.BBSSHELL_HOME_DIR_PATH);
        environment.add("PREFIX=" + BbsShellConstants.BBSSHELL_PREFIX_DIR_PATH);
        environment.add("BBSSHELL__PREFIX=" + BbsShellConstants.BBSSHELL_PREFIX_DIR_PATH);

        environment.add("BBSSHELL__SE_PROCESS_CONTEXT=" + SELinuxUtils.getContext());

        environment.add("BOOTCLASSPATH=" + System.getenv("BOOTCLASSPATH"));
        environment.add("ANDROID_ROOT=" + System.getenv("ANDROID_ROOT"));
        environment.add("ANDROID_DATA=" + System.getenv("ANDROID_DATA"));
        // EXTERNAL_STORAGE is needed for /system/bin/am to work on at least
        // Samsung S7 - see https://plus.google.com/110070148244138185604/posts/gp8Lk3aCGp3.
        environment.add("EXTERNAL_STORAGE=" + System.getenv("EXTERNAL_STORAGE"));

        // These variables are needed if running on Android 10 and higher.
        addToEnvIfPresent(environment, "ANDROID_ART_ROOT");
        addToEnvIfPresent(environment, "DEX2OATBOOTCLASSPATH");
        addToEnvIfPresent(environment, "ANDROID_I18N_ROOT");
        addToEnvIfPresent(environment, "ANDROID_RUNTIME_ROOT");
        addToEnvIfPresent(environment, "ANDROID_TZDATA_ROOT");

        environment.add("ANDROID__BUILD_VERSION_SDK=" + Build.VERSION.SDK_INT);

        if (isFailSafe) {
            // Keep the default path so that system binaries can be used in the failsafe session.
            environment.add("PATH= " + System.getenv("PATH"));
        } else {
            environment.add("LANG=en_US.UTF-8");
            environment.add("PATH=" + BbsShellConstants.BBSSHELL_BIN_PREFIX_DIR_PATH);
            environment.add("PWD=" + workingDirectory);
            environment.add("TMPDIR=" + BbsShellConstants.BBSSHELL_TMP_PREFIX_DIR_PATH);
        }

        return environment.toArray(new String[0]);
    }

    public static void addToEnvIfPresent(List<String> environment, String name) {
        String value = System.getenv(name);
        if (value != null) {
            environment.add(name + "=" + value);
        }
    }

    public static String[] setupProcessArgs(@NonNull String fileToExecute, String[] arguments) {
        // The file to execute may either be:
        // - An elf file, in which we execute it directly.
        // - A script file without shebang, which we execute with our standard shell $PREFIX/bin/sh instead of the
        //   system /system/bin/sh. The system shell may vary and may not work at all due to LD_LIBRARY_PATH.
        // - A file with shebang, which we try to handle with e.g. /bin/foo -> $PREFIX/bin/foo.
        String interpreter = null;
        try {
            File file = new File(fileToExecute);
            try (FileInputStream in = new FileInputStream(file)) {
                byte[] buffer = new byte[256];
                int bytesRead = in.read(buffer);
                if (bytesRead > 4) {
                    if (buffer[0] == 0x7F && buffer[1] == 'E' && buffer[2] == 'L' && buffer[3] == 'F') {
                        // Elf file, do nothing.
                    } else if (buffer[0] == '#' && buffer[1] == '!') {
                        // Try to parse shebang.
                        StringBuilder builder = new StringBuilder();
                        for (int i = 2; i < bytesRead; i++) {
                            char c = (char) buffer[i];
                            if (c == ' ' || c == '\n') {
                                if (builder.length() == 0) {
                                    // Skip whitespace after shebang.
                                } else {
                                    // End of shebang.
                                    String executable = builder.toString();
                                    if (executable.startsWith("/usr") || executable.startsWith("/bin")) {
                                        String[] parts = executable.split("/");
                                        String binary = parts[parts.length - 1];
                                        interpreter = BbsShellConstants.BBSSHELL_BIN_PREFIX_DIR_PATH + "/" + binary;
                                    }
                                    break;
                                }
                            } else {
                                builder.append(c);
                            }
                        }
                    } else {
                        // No shebang and no ELF, use standard shell.
                        interpreter = BbsShellConstants.BBSSHELL_BIN_PREFIX_DIR_PATH + "/sh";
                    }
                }
            }
        } catch (IOException e) {
            // Ignore.
        }

        List<String> result = new ArrayList<>();
        if (interpreter != null) result.add(interpreter);
        result.add(fileToExecute);
        if (arguments != null) Collections.addAll(result, arguments);
        return result.toArray(new String[0]);
    }

    public static void clearBbsShellTMPDIR(boolean onlyIfExists) {
        if(onlyIfExists && !FileUtils.directoryFileExists(BbsShellConstants.BBSSHELL_TMP_PREFIX_DIR_PATH, false))
            return;

        Error error;
        error = FileUtils.clearDirectory("$TMPDIR", FileUtils.getCanonicalPath(BbsShellConstants.BBSSHELL_TMP_PREFIX_DIR_PATH, null));
        if (error != null) {
            Logger.logErrorExtended(error.toString());
        }
    }

    public static void loadBbsShellEnvVariables(Context currentPackageContext) {
        String bbsshellAPKReleaseOld = BBSSHELL_APK_RELEASE;
        BBSSHELL_VERSION_NAME = BBSSHELL_IS_DEBUGGABLE_BUILD = BBSSHELL_APP_PID = BBSSHELL_APK_RELEASE = null;

        // Check if BbsShell app is installed and not disabled
        if (BbsShellUtils.isBbsShellAppInstalled(currentPackageContext) == null) {
            // This function may be called by a different package like a plugin, so we get version for BbsShell package via its context
            Context bbsshellPackageContext = BbsShellUtils.getBbsShellPackageContext(currentPackageContext);
            if (bbsshellPackageContext != null) {
                BBSSHELL_VERSION_NAME = PackageUtils.getVersionNameForPackage(bbsshellPackageContext);
                BBSSHELL_IS_DEBUGGABLE_BUILD = PackageUtils.isAppForPackageADebuggableBuild(bbsshellPackageContext) ? "1" : "0";

                BBSSHELL_APP_PID = BbsShellUtils.getBbsShellAppPID(currentPackageContext);

                // Getting APK signature is a slightly expensive operation, so do it only when needed
                if (bbsshellAPKReleaseOld == null) {
                    String signingCertificateSHA256Digest = PackageUtils.getSigningCertificateSHA256DigestForPackage(bbsshellPackageContext);
                    if (signingCertificateSHA256Digest != null)
                        BBSSHELL_APK_RELEASE = BbsShellUtils.getAPKRelease(signingCertificateSHA256Digest).replaceAll("[^a-zA-Z]", "_").toUpperCase();
                } else {
                    BBSSHELL_APK_RELEASE = bbsshellAPKReleaseOld;
                }
            }
        }
    }

}
