LOCAL_PATH:= $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE:= libbbsshell
LOCAL_SRC_FILES:= bbsshell.c
include $(BUILD_SHARED_LIBRARY)
